<?php
include('db.php');


$sql = "
    SELECT 
        add_pets.* 
    FROM 
        add_pets 
    WHERE 
        upload = 1 
    ORDER BY 
        age ASC;
";

$petdel = $conn->query($sql);


$searchResults = [];
$categoryResults = [];


if (isset($_POST['search'])) {
    $data = mysqli_real_escape_string($conn, $_POST['data']);

    $search = "
        SELECT * 
        FROM 
            add_pets
        WHERE upload=1 and 
            (pet_category LIKE '%$data%' OR pet_breed LIKE '%$data%' OR pet_name LIKE '%$data%')
        ORDER BY 
            age ASC
    ";

    $searchResults = $conn->query($search);
}


if (isset($_POST['category'])) {
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $categoryQuery = "
        SELECT * 
        FROM add_pets 
        WHERE pet_category = '$category' AND upload = 1
        ORDER BY age ASC
    ";

    $categoryResults = $conn->query($categoryQuery);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Homepage</title>
    <link rel="stylesheet" href="./home.css?v=<?php echo time(); ?>">
</head>

<body>

    <div id="home">
        <?php include 'nav.php'; ?>

        <form action="Home.php" method="post">
            <section class="second">
                <div class="search">
                    <input type="text" class="searchbox" placeholder="Search for pets" id="tags" name="data" />
                    <button name="search">
                        Search
                    </button>
                </div>
            </section>
        </form>

        <section class="imgdiv">
            <div class="img">
                <form action="Home.php" method="post">
                    <button type="submit" name="category" value="cat"><img src="photo/cat.jpg" alt="Cat" /></button>
                    <button type="submit" name="category" value="rabbit"><img src="./photo/rabit.jpg" alt="Rabbit" /></button>
                    <button type="submit" name="category" value="bird"><img src="photo/birds.jpg" alt="Birds" /></button>
                    <button type="submit" name="category" value="rat"><img src="photo/rat.jpg" alt="Rat" /></button>
                    <button type="submit" name="category" value="dog"><img src="photo/dog.jpg" alt="Dog" /></button>
                </form>
            </div>
        </section>

        <main>
            <section class="pet-cart">
                <h1 style="text-align: center;">Our Pets Collection</h1>
                <div class="pet-cart1">
                    <?php

                    if (isset($_POST['search']) && $searchResults->num_rows > 0) {
                        while ($row = $searchResults->fetch_assoc()) {
                            displayPet($row);
                        }
                    } elseif (isset($_POST['category']) && $categoryResults->num_rows > 0) {
                        while ($row = $categoryResults->fetch_assoc()) {
                            displayPet($row);
                        }
                    } elseif ($petdel->num_rows > 0) {
                        while ($row = $petdel->fetch_assoc()) {
                            displayPet($row);
                        }
                    } else {
                        echo "No pets available.";
                    }


                    function displayPet($row)
                    {
                    ?>
                        <div class="pet-item">
                            <img src="<?php echo htmlspecialchars($row['pet_photos']); ?>" alt="Pet Photo" class="pet-photo" />
                            <div class="pet-info">
                                <h3 class="pet-name">Name: <?php echo htmlspecialchars($row['pet_name']); ?></h3>
                                <p class="pet-breed">Species: <?php echo htmlspecialchars($row['pet_category']); ?></p>
                                <p class="pet-breed">Breed: <?php echo htmlspecialchars($row['pet_breed']); ?></p>
                                <p class="pet-age">Age: <?php echo htmlspecialchars($row['age']); ?></p>
                                <p class="pet-price">Price: RS<?php echo htmlspecialchars($row['price']); ?></p>
                                <div class="pet-buttons">
                                    <button class="btn-details"
                                        onclick="alertAndRedirect('login.php?id=<?php echo htmlspecialchars($row['pet_id']); ?>')">Details</button>
                                    <button class="btn-adopt"
                                        onclick="alertAndRedirect('login.php')">Adopt</button>

                                    <script>
                                        function alertAndRedirect(url) {
                                            alert("You need to login first, please!!!!!!");
                                            window.location.href = url;
                                        }
                                    </script>
                                </div>
                            </div>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            </section>
        </main>
        <?php include 'footer.php'; ?>
    </div>

</body>

</html>