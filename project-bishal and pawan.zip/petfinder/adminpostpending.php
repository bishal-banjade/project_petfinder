<?php
// Include database connection
include 'db.php';

// Fetch pending requests from add_pets where upload = 0
$sql = "
    SELECT 
        pet_id, 
        owner_id, 
        owner_name, 
        owner_email, 
        owner_address, 
        phone_no, 
        pet_name, 
        pet_category, 
        price, 
        pet_photos 
    FROM 
        add_pets 
    WHERE 
        upload = 0
";
$result = $conn->query($sql);

// Fetch new messages (upload = 0)
$newMessagesResult = $conn->query("SELECT COUNT(*) as total FROM add_pets WHERE upload = 0");
$newMessages = $newMessagesResult->fetch_assoc()['total'];

// Fetch successful transactions (success = 1)
$successfulTransactionsResult = $conn->query("SELECT COUNT(*) as total FROM add_pets WHERE success = 1 AND payment = 0");
$successfulTransactions = $successfulTransactionsResult->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Pending Requests</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
        }

        table {
            margin-top: 2rem;
            /* Reduced margin for better fit */
            width: 100%;
            border-collapse: collapse;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            background-color: #fff;
            border-radius: 8px;
            overflow: hidden;
            table-layout: fixed;
            /* Fixed layout for consistent column widths */
        }

        .header-menu .user .home-button span {
            margin-right: 0.5rem;
            /* Space between icon and text */
            font-size: 1.5rem;
            /* Adjust size as needed */
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 10px;
            /* Adjusted padding */
            text-align: center;
            word-wrap: break-word;
            /* Allow word wrap in table cells */
        }

        th {
            background-color: #4CAF50;
            color: white;
            text-transform: uppercase;
            letter-spacing: 0.1em;
        }



        /* Set specific widths for columns */
        th:nth-child(1),
        td:nth-child(1) {
            width: 5%;
        }

        /* ID */
        th:nth-child(2),
        td:nth-child(2) {
            width: 15%;
        }

        /* Owner Name */
        th:nth-child(3),
        td:nth-child(3) {
            width: 15%;
        }

        /* Owner Email */
        th:nth-child(4),
        td:nth-child(4) {
            width: 20%;
        }

        /* Owner Address */
        th:nth-child(5),
        td:nth-child(5) {
            width: 10%;
        }

        /* Phone Number */
        th:nth-child(6),
        td:nth-child(6) {
            width: 10%;
        }

        /* Pet Name */
        th:nth-child(7),
        td:nth-child(7) {
            width: 10%;
        }

        /* Pet Type */
        th:nth-child(8),
        td:nth-child(8) {
            width: 5%;
        }

        /* Price */
        th:nth-child(9),
        td:nth-child(9) {
            width: 10%;
        }

        /* Pet Photo */
        th:nth-child(10),
        td:nth-child(10) {
            width: 15%;
        }

        /* Actions */

        img {
            max-width: 100px;
            /* Responsive image */
            height: auto;
            border-radius: 5px;
            box-shadow: 0 1px 5px rgba(0, 0, 0, 0.2);
        }

        button {
            padding: 10px 15px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin: 0;
            cursor: pointer;
            border-radius: 5px;
            border: none;
            transition: background-color 0.3s ease, transform 0.1s ease;
        }

        button.approve {
            background-color: #4CAF50;
            color: white;
        }

        button.reject {
            background-color: #f44336;
            color: white;
        }

        button:hover {
            transform: scale(1.05);
        }

        button.approve:hover {
            background-color: #45a049;
        }

        button.reject:hover {
            background-color: #d32f2f;
        }

        .action-buttons {
            display: flex;
            gap: 5px;
            justify-content: center;
        }

        @media (max-width: 768px) {

            table,
            th,
            td {
                display: block;
                /* Stack elements vertically on smaller screens */
                width: 100%;
                /* Full width */
            }

            th {
                position: absolute;
                /* Position th elements off-screen */
                left: -9999px;
                /* Hide them */
            }

            tr {
                margin-bottom: 1rem;
                /* Space between rows */
                border: 1px solid #ddd;
                /* Add border for better separation */
            }

            td {
                text-align: left;
                /* Align text to the left */
                padding-left: 50%;
                /* Space for pseudo-elements */
                position: relative;
                /* Position children relative */
            }

            td:before {
                content: attr(data-label);
                /* Use data-label for headers */
                position: absolute;
                left: 10px;
                /* Adjust for spacing */
                width: 50%;
                /* Half width */
                white-space: nowrap;
                /* Prevent wrapping */
                font-weight: bold;
                /* Make it bold */
            }
        }
    </style>
</head>

<body>
    <?php include 'adminnav.php'; ?>

    <h2>Pending Requests</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Owner Name</th>
                <th>Owner Email</th>
                <th>Owner Address</th>
                <th>Phone Number</th>
                <th>Pet Name</th>
                <th>Pet Type</th>
                <th>Price</th>
                <th>Pet Photo</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td data-label="ID"><?php echo $row['pet_id']; ?></td>
                        <td data-label="Owner Name"><?php echo $row['owner_name']; ?></td>
                        <td data-label="Owner Email"><?php echo $row['owner_email']; ?></td>
                        <td data-label="Owner Address"><?php echo $row['owner_address']; ?></td>
                        <td data-label="Phone Number"><?php echo $row['phone_no']; ?></td>
                        <td data-label="Pet Name"><?php echo $row['pet_name']; ?></td>
                        <td data-label="Pet Type"><?php echo $row['pet_category']; ?></td>
                        <td data-label="Price"><?php echo $row['price']; ?></td>
                        <td data-label="Pet Photo"><img src="<?php echo htmlspecialchars($row['pet_photos']); ?>" alt="Pet Photo" class="pet-photo" /></td>
                        <td data-label="Actions">
                            <div class="action-buttons">
                                <form action="approve.php" method="POST" style="display:inline;">
                                    <input type="hidden" name="pet_id" value="<?php echo $row['pet_id']; ?>">
                                    <button type="submit" name="action" value="approve" class="approve">Approve</button>
                                </form>
                                <form action="update_request.php" method="POST" style="display:inline;">
                                    <input type="hidden" name="pet_id" value="<?php echo $row['pet_id']; ?>">
                                    <button type="submit" name="action" value="reject" class="reject">Reject</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="10">No pending requests found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    </div>
    <?php $conn->close(); ?>
</body>

</html>