function previewImage(event) {
  const image = document.getElementById("profileImage");
  const file = event.target.files[0];
  const reader = new FileReader();

  reader.onload = function () {
    image.src = reader.result; // Replace the source with the uploaded image
  };

  if (file) {
    reader.readAsDataURL(file); // Read the image file
  }
}

function nextTab(currentTabId, nextTabId) {
  const currentTab = document.getElementById(currentTabId);
  const nextTab = document.getElementById(nextTabId);
  const inputs = currentTab.querySelectorAll(
    "input[required], textarea[required]"
  );
  let valid = true;

  inputs.forEach((input) => {
    if (!input.value) {
      valid = false;
      input.classList.add("error"); // Optional: Add a class to highlight the error
    } else {
      input.classList.remove("error"); // Remove error class if valid
    }
  });

  // If all required fields are filled, proceed to the next tab
  if (valid) {
    currentTab.classList.remove("active"); // Hide current tab
    nextTab.classList.add("active"); // Show next tab

    // Update confirmation details if moving to the final tab
    if (nextTabId === "finalConfirmation") {
      document.getElementById("confirmName").innerText =
        document.getElementById("full_name").value;
      document.getElementById("confirmEmail").innerText =
        document.getElementById("contact_email").value;
      document.getElementById("confirmPhone").innerText =
        document.getElementById("phone_number").value;
      document.getElementById("confirmAddress").innerText =
        document.getElementById("address").value;
      document.getElementById("confirmReason").innerText =
        document.getElementById("adoption_reason").value;
    }
  } else {
    alert("Please fill in all required fields."); // Alert user to fill all fields
  }
}
