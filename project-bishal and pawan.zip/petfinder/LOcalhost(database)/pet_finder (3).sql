-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 20, 2025 at 04:08 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pet_finder`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_pets`
--

CREATE TABLE `add_pets` (
  `pet_id` int(11) NOT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `owner_name` varchar(255) NOT NULL,
  `owner_email` varchar(255) NOT NULL,
  `owner_address` varchar(255) NOT NULL,
  `phone_no` varchar(50) NOT NULL,
  `pet_name` varchar(255) NOT NULL,
  `pet_category` varchar(255) NOT NULL,
  `age` float DEFAULT NULL,
  `pet_breed` varchar(255) DEFAULT NULL,
  `weight` float NOT NULL,
  `spayed` varchar(10) NOT NULL DEFAULT 'No',
  `health_status` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `Reasontosale` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `pet_photos` varchar(255) DEFAULT NULL,
  `upload` tinyint(1) NOT NULL DEFAULT 0,
  `dealout` tinyint(1) NOT NULL DEFAULT 0,
  `success` tinyint(1) NOT NULL DEFAULT 0,
  `payment` tinyint(4) NOT NULL DEFAULT 0,
  `payment_id` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `add_pets`
--

INSERT INTO `add_pets` (`pet_id`, `owner_id`, `owner_name`, `owner_email`, `owner_address`, `phone_no`, `pet_name`, `pet_category`, `age`, `pet_breed`, `weight`, `spayed`, `health_status`, `description`, `Reasontosale`, `price`, `pet_photos`, `upload`, `dealout`, `success`, `payment`, `payment_id`, `created_at`) VALUES
(1, 4, 'Bishal Banjade', 'manbishalbanjade@gmail.com', 'tilottama-01 banbitika', '9843906797', 'Max', 'dog', 4, 'Himalayan dog', 15, 'No', 'health status of max is well good,sometimes he need extra care.', 'max shape looks like bold and black in color,he like to play with other', 'Breeders or pet owners may sell unexpected litters to find homes for the animals.', 7.99, 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1729757223/kv7ylknsz8anzrloagar.jpg', 1, 1, 1, 0, 0, '2024-12-08 10:24:52'),
(3, 4, 'Bishal Banjade', 'manbishalbanjade@gmail.com', 'tilottama-01 banbitika', '9843906797', 'Whiskers', 'cat', 2, 'Domestic Shorthair', 4.5, 'No', 'Healthy, treated for parasites.', 'Playful and affectionate; enjoys cuddling on cold nights', 'Some pets are sold for educational purposes, such as teaching children about responsibility and care.', 1.00, 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1729791548/st4kq3kc43ckwldz410u.jpg', 1, 0, 0, 0, 0, '2024-12-08 10:24:52'),
(4, 4, 'Bishal Banjade', 'manbishalbanjade@gmail.com', 'tilottama-01 banbitika', '9843906797', 'Fluffy', 'Rabbit', 2, ' Netherland Dwarf', 1.5, 'No', 'Healthy, vaccinated.\r\n', ': Small and friendly; loves to be handled.', 'Breeders may sell their remaining stock as they retire from breeding.', 50.00, 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1729795876/yup3dl3z6rehqls3yw0o.jpg', 1, 1, 1, 0, 581, '2024-12-08 10:24:52'),
(5, 4, 'Bishal Banjade', 'manbishalbanjade@gmail.com', 'tilottama-01 banbitika', '9843906797', 'Leo', 'cat', 3, ' Maine Coon', 6, 'No', 'Healthy, vaccinated.', 'Large and friendly; loves to play.', 'People relocating to places that do not allow pets may need to sell them.', 70.00, 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1729824547/lh73bbvfw5v6u7cfdidp.jpg', 1, 0, 0, 0, 0, '2024-12-08 10:24:52'),
(6, 4, 'Bishal Banjade', 'manbishalbanjade@gmail.com', 'tilottama-01 banbitika', '9843906797', 'Socks', 'cat', 4, 'Persian cat', 3.5, 'No', ' Healthy, no issues.', 'Fluffy and affectionate; needs grooming.', 'Rescued animals may be rehabilitated and then sold to find them permanent homes.', 1.00, 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1729824855/h7ygg61nnnzuyj2pugwo.jpg', 1, 0, 0, 0, 0, '2024-12-08 10:24:52'),
(7, 4, 'Bishal Banjade', 'manbishalbanjade@gmail.com', 'tilottama-01 banbitika', '9843906797', 'minu', 'Rabbit', 1, 'Dwarf Hotot', 1.4, 'No', ' Healthy, no known issues.\r\n', 'White with black markings; very social.', 'Owners may decide to sell their current pet to adopt a different breed or species that better fits their lifestyle or preferences.', 30.00, 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1729825240/hk9t8w16wye7g12ygxcj.webp', 1, 1, 0, 0, 0, '2024-12-08 10:24:52'),
(8, 4, 'Bishal Banjade', 'manbishalbanjade@gmail.com', 'tilottama-01 banbitika', '9843906797', 'Goldfish', 'Fish', 1, 'Common Goldfish', 0.1, 'No', 'Healthy, active', 'Bright orange; easy to care for.', 'Some individuals may develop allergies to pets, leading them to sell or rehome them.\n', 10.00, 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1729825463/jebjkkg9y8epuf5l9zkf.jpg', 0, 0, 0, 0, 0, '2024-12-08 10:24:52'),
(9, 4, 'Bishal Banjade', 'manbishalbanjade@gmail.com', 'tilottama-01 banbitika', '9843906797', 'batman', 'dog', 3, 'BullDog', 15, 'No', 'Generally healthy, slight hip dysplasia.', ' Gentle and friendly; loves swimming in rivers', 'Allergies to family', 150.00, 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1729825591/ugaadebdfp8bculawzii.jpg', 1, 0, 0, 0, 0, '2024-12-08 10:24:52'),
(10, 4, 'Bishal Banjade', 'manbishalbanjade@gmail.com', 'tilottama-01 banbitika', '9843906797', 'Thumper', 'Rabbit', 4.2, 'Flemish Giant', 6.7, 'No', 'Healthy, needs space.', 'Gentle giant; great for families.', 'Owners may sell pets due to lifestyle changes, such as moving, job changes, or family situations, which make it difficult to care for the pet', 7.00, 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1729826694/gkud8vcmw7azubdslruu.webp', 1, 0, 0, 0, 0, '2024-12-08 10:24:52'),
(11, 4, 'Bishal Banjade', 'manbishalbanjade@gmail.com', 'tilottama-01 banbitika', '9843906797', 'Bella', 'bird', 1.5, 'Parakeet', 0.6, 'No', 'Healthy, active.', 'Friendly and vibrant; loves to chirp.', 'Some pets may be sold due to health conditions that require specialized care that the current owner cannot provide.', 35.00, 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1729828312/tzsjjis1zn0lrvrdxzlt.jpg', 1, 0, 0, 0, 0, '2024-12-08 10:24:52'),
(12, 4, 'Bishal Banjade', 'manbishalbanjade@gmail.com', 'tilottama-01 banbitika', '9843906797', 'Charlie', 'bird', 5, 'Amazon Parrot', 0.4, 'No', 'Healthy, requires special diet.', 'Talkative and affectionate; enjoys interaction.', 'helters and rescue organizations often sell or adopt out pets to reduce the number of homeless animals.', 0.04, 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1729831466/zjvqkf5ot9ombds3s8n4.jpg', 1, 0, 0, 0, 0, '2024-12-08 10:24:52'),
(13, 4, 'Bishal Banjade', 'manbishalbanjade@gmail.com', 'tilottama-01 banbitika', '9843906797', 'Milo', 'Tortoise', 6, 'Aldabra Tortoise', 10, 'No', 'Healthy, requires special diet.', 'Large and gentle; needs plenty of space.', 'Selling pets can be a source of income for breeders, pet shops, or individuals who may need to cover expenses.', 0.07, 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1729832131/fticmac2zemey3llwbuh.jpg', 1, 0, 0, 0, 0, '2024-12-08 10:24:52'),
(14, 5, 'Rubi Ale', 'manbishalbanjade07@gmail.com', 'tilottama-02 banbitika', '9816495566', 'Max', 'dog', 2, 'Boxer', 18, 'No', 'Healthy, energetic.', 'Playful and loyal, loves to be around people.', 'Busy schedules or personal commitments may lead individuals to sell pets if they cannot devote enough time to their care.\n', 87.00, 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1729834625/w47l2wgfg6onatoez6jm.jpg', 1, 0, 0, 0, 0, '2024-12-08 10:24:52'),
(15, 5, 'Rubi Ale', 'manbishalbanjade07@gmail.com', 'tilottama-02 banbitika', '9816495566', 'Mittens', 'cat', 3, 'Ragdoll', 15, 'No', 'Healthy, indoor-only cat.', 'Laid-back and affectionate, great for families.', 'Pets that require extensive training or have behavioral issues may be sold by owners who feel unable to manage their needs.', 67.00, 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1729834821/jsqyhtfny3hxbwk6x97h.jpg', 1, 1, 1, 1, 778, '2024-12-08 10:24:52'),
(16, 4, 'Bishal Banjade', 'manbishalbanjade@gmail.com', 'tilottama-01 banbitika', '9843906797', 'Rocky', 'dog', 4, 'Golden Retriever', 25, 'No', 'Healthy, fully vaccinated.', 'Friendly and energetic; loves outdoor activities in the hills.', 'little bit busy', 60.00, 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1732121923/ypcensmcjuypxnwjadkk.jpg', 1, 0, 0, 0, 0, '2024-12-08 10:24:52'),
(17, 5, 'Rubi Ale', 'manbishalbanjade07@gmail.com', 'tilottama-02 banbitika', '9816495566', 'Max', 'cat', 5, 'Ragdoll', 14, 'No', 'fit and fine', 'max is very happy to play with children and sometimes he left his food to play with them', 'littlebit busy', 90.00, 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1733331604/pug4ujagndw8bji2qoqx.jpg', 1, 0, 0, 0, 0, '2024-12-08 10:24:52'),
(18, 5, 'Rubi Ale', 'manbishalbanjade07@gmail.com', 'tilottama-02 banbitika', '9816495566', 'pinky', 'mammal', 5, 'hamster', 4.5, 'No', 'superhealthy', 'she loves play with childs', '', 7.00, 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1735232369/ltxkxguwehtuasphjid3.jpg', 0, 0, 0, 0, 0, '2024-12-26 16:59:30');

-- --------------------------------------------------------

--
-- Table structure for table `adopter`
--

CREATE TABLE `adopter` (
  `adopt_id` int(11) NOT NULL,
  `pet_id` int(11) NOT NULL,
  `adopter_id` int(11) NOT NULL,
  `adopter_name` varchar(100) NOT NULL,
  `adopter_email` varchar(50) NOT NULL,
  `Adopter_reason` varchar(100) NOT NULL,
  `adopter_phone` varchar(200) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `adopter_photo` varchar(255) NOT NULL,
  `agree_condition` tinyint(1) NOT NULL,
  `D_front` varchar(255) NOT NULL,
  `D_back` varchar(255) NOT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `own_pets` enum('yes','no') DEFAULT NULL,
  `vet_name` varchar(255) DEFAULT NULL,
  `home_status` enum('Own','Rent') DEFAULT NULL,
  `yard` enum('Yes','No') DEFAULT NULL,
  `landlord_policy` text DEFAULT NULL,
  `children` varchar(255) DEFAULT NULL,
  `hours_alone` int(11) DEFAULT NULL,
  `animal_crime` enum('Yes','No') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adopter`
--

INSERT INTO `adopter` (`adopt_id`, `pet_id`, `adopter_id`, `adopter_name`, `adopter_email`, `Adopter_reason`, `adopter_phone`, `Address`, `adopter_photo`, `agree_condition`, `D_front`, `D_back`, `city`, `state`, `country`, `own_pets`, `vet_name`, `home_status`, `yard`, `landlord_policy`, `children`, `hours_alone`, `animal_crime`) VALUES
(8, 15, 4, 'bishal banjade', 'manbishalbanjade@gmail.com', 'i like this pet', '9843906797', 'drivertole', 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1733418509/kblimlyjoduimy8zik6e.jpg', 1, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(11, 4, 5, 'Biksham bhandari', 'manbishalbanjade07@gmail.com', 'i love this so', '9843906797', 'tilottama-01 banbitika', 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1735201106/i3wk5ojtl6lzihumtaod.jpg', 1, 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1735201113/eogeoxrdlyaqdwcgptwo.jpg', 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1735201121/zfywnpjxsfcidrdffyg3.jpg', 'butwal', 'lumbini', 'Nepal', 'yes', 'Rabinhood', '', 'No', NULL, 'no', 2, 'Yes'),
(12, 7, 5, 'Biksham bhandari', 'manbishalbanjade07@gmail.com', 'it is small pet i love this', '9843906797', 'tilottama-01 banbitika', 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1735202587/k68nxscfwakbyvjqaivn.jpg', 1, 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1735202595/ykqnrsjfyqjvgkdvltuv.jpg', 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1735202602/c0zunl0zd9z5c3b3anzq.jpg', 'butwal', 'lumbini', 'Nepal', 'yes', 'Rabinhood', '', 'Yes', NULL, 'no', 2, 'Yes'),
(13, 1, 5, 'Biksham bhandari', 'manbishalbanjade0@gmail.com', 'i love this pet', '9843906797', 'tilottama-01 banbitika', 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1735266760/gtgiyvgwgu2nlzhy12io.jpg', 1, 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1735266763/mxcwmim6j23nb0muvqhy.jpg', 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1735266765/lu1fqy5tzgdsgtsbvyyc.jpg', 'butwal', 'lumbini', 'Nepal', 'no', '', '', 'Yes', NULL, 'no', 2, 'No');

-- --------------------------------------------------------

--
-- Table structure for table `traffic_logs`
--

CREATE TABLE `traffic_logs` (
  `id` int(11) NOT NULL,
  `visit_date` date NOT NULL,
  `page` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `traffic_logs`
--

INSERT INTO `traffic_logs` (`id`, `visit_date`, `page`, `user_id`) VALUES
(32, '2024-12-16', 'dashboard.php', 4),
(33, '2024-12-16', 'dashboard.php', 4),
(34, '2024-12-16', 'dashboard.php', 4),
(35, '2024-12-16', 'dashboard.php', 4),
(36, '2024-12-16', 'dashboard.php', 4),
(37, '2024-12-16', 'dashboard.php', 4),
(38, '2024-12-20', 'dashboard.php', 4),
(39, '2024-12-20', 'dashboard.php', 4),
(40, '2024-12-22', 'dashboard.php', 4),
(41, '2024-12-25', 'dashboard.php', 4),
(42, '2024-12-25', 'dashboard.php', 4),
(43, '2024-12-25', 'dashboard.php', 4),
(44, '2024-12-25', 'dashboard.php', 4),
(45, '2024-12-25', 'dashboard.php', 4),
(46, '2024-12-25', 'dashboard.php', 4),
(47, '2024-12-25', 'dashboard.php', 4),
(48, '2024-12-25', 'dashboard.php', 4),
(49, '2024-12-25', 'dashboard.php', 4),
(50, '2024-12-25', 'dashboard.php', 4),
(51, '2024-12-25', 'dashboard.php', 4),
(52, '2024-12-25', 'dashboard.php', 4),
(53, '2024-12-25', 'dashboard.php', 4),
(54, '2024-12-25', 'dashboard.php', 4),
(55, '2024-12-26', 'dashboard.php', 4),
(56, '2024-12-26', 'dashboard.php', 4),
(57, '2024-12-26', 'dashboard.php', 4),
(58, '2024-12-26', 'dashboard.php', 4),
(59, '2024-12-26', 'dashboard.php', 4),
(60, '2024-12-26', 'dashboard.php', 4),
(61, '2024-12-26', 'dashboard.php', 4),
(62, '2024-12-26', 'dashboard.php', 4),
(63, '2024-12-26', 'dashboard.php', 4),
(64, '2024-12-26', 'dashboard.php', 4),
(65, '2024-12-26', 'dashboard.php', 4),
(66, '2024-12-26', 'dashboard.php', 4),
(67, '2024-12-26', 'dashboard.php', 4),
(68, '2024-12-26', 'dashboard.php', 4),
(69, '2024-12-26', 'dashboard.php', 4),
(70, '2024-12-26', 'dashboard.php', 4),
(71, '2024-12-26', 'dashboard.php', 4),
(72, '2024-12-26', 'dashboard.php', 4),
(73, '2024-12-26', 'dashboard.php', 4),
(74, '2024-12-26', 'dashboard.php', 4),
(75, '2024-12-26', 'dashboard.php', 4),
(76, '2024-12-26', 'dashboard.php', 4),
(77, '2024-12-26', 'dashboard.php', 4),
(78, '2024-12-26', 'dashboard.php', 4),
(79, '2024-12-26', 'dashboard.php', 4),
(80, '2024-12-26', 'dashboard.php', 4),
(81, '2024-12-26', 'dashboard.php', 4),
(82, '2024-12-26', 'dashboard.php', 4),
(83, '2024-12-26', 'dashboard.php', 4),
(84, '2024-12-26', 'dashboard.php', 4),
(85, '2024-12-26', 'dashboard.php', 4),
(86, '2024-12-26', 'dashboard.php', 4),
(87, '2024-12-26', 'dashboard.php', 4),
(88, '2024-12-26', 'dashboard.php', 4),
(89, '2024-12-26', 'dashboard.php', 4),
(90, '2024-12-26', 'dashboard.php', 4),
(91, '2024-12-26', 'dashboard.php', 5),
(92, '2024-12-26', 'dashboard.php', 5),
(93, '2024-12-26', 'dashboard.php', 5),
(94, '2024-12-26', 'dashboard.php', 5),
(95, '2024-12-26', 'dashboard.php', 5),
(96, '2024-12-26', 'dashboard.php', 5),
(97, '2024-12-26', 'dashboard.php', 5),
(98, '2024-12-26', 'dashboard.php', 5),
(99, '2024-12-26', 'dashboard.php', 5),
(100, '2024-12-26', 'dashboard.php', 4),
(101, '2024-12-26', 'dashboard.php', 4),
(102, '2024-12-26', 'dashboard.php', 4),
(103, '2024-12-26', 'dashboard.php', 4),
(104, '2024-12-26', 'dashboard.php', 5),
(105, '2024-12-26', 'dashboard.php', 5),
(106, '2024-12-26', 'dashboard.php', 5),
(107, '2024-12-26', 'dashboard.php', 5),
(108, '2024-12-26', 'dashboard.php', 4),
(109, '2024-12-26', 'dashboard.php', 5),
(110, '2024-12-26', 'dashboard.php', 4),
(111, '2024-12-26', 'dashboard.php', 5),
(112, '2024-12-26', 'dashboard.php', 5),
(113, '2024-12-26', 'dashboard.php', 5),
(114, '2024-12-26', 'dashboard.php', 5),
(115, '2024-12-26', 'dashboard.php', 4),
(116, '2024-12-26', 'dashboard.php', 4),
(117, '2024-12-26', 'dashboard.php', 4),
(118, '2024-12-27', 'dashboard.php', 5),
(119, '2024-12-27', 'dashboard.php', 5),
(120, '2024-12-27', 'dashboard.php', 5),
(121, '2024-12-27', 'dashboard.php', 5),
(122, '2024-12-27', 'dashboard.php', 5),
(123, '2024-12-27', 'dashboard.php', 5),
(124, '2024-12-27', 'dashboard.php', 5),
(125, '2024-12-27', 'dashboard.php', 4),
(126, '2024-12-27', 'dashboard.php', 4),
(127, '2024-12-27', 'dashboard.php', 5),
(128, '2024-12-27', 'dashboard.php', 5),
(129, '2024-12-27', 'dashboard.php', 4),
(130, '2024-12-27', 'dashboard.php', 4),
(131, '2024-12-27', 'dashboard.php', 4),
(132, '2024-12-27', 'dashboard.php', 4),
(133, '2024-12-27', 'dashboard.php', 5),
(134, '2024-12-27', 'dashboard.php', 5),
(135, '2024-12-27', 'dashboard.php', 4),
(136, '2024-12-27', 'dashboard.php', 5),
(137, '2025-01-18', 'dashboard.php', 4),
(138, '2025-01-18', 'dashboard.php', 4),
(139, '2025-01-18', 'dashboard.php', 4),
(140, '2025-01-18', 'dashboard.php', 4),
(141, '2025-01-18', 'dashboard.php', 4),
(142, '2025-01-20', 'dashboard.php', 4),
(143, '2025-01-20', 'dashboard.php', 7),
(144, '2025-01-20', 'dashboard.php', 4),
(145, '2025-01-20', 'dashboard.php', 4),
(146, '2025-01-20', 'dashboard.php', 4);

-- --------------------------------------------------------

--
-- Table structure for table `update_pet`
--

CREATE TABLE `update_pet` (
  `update_id` int(11) NOT NULL,
  `pet_id` int(11) NOT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `pet_name` varchar(255) NOT NULL,
  `pet_category` varchar(255) NOT NULL,
  `age` float DEFAULT NULL,
  `pet_breed` varchar(255) DEFAULT NULL,
  `weight` float NOT NULL,
  `spayed` varchar(10) NOT NULL DEFAULT 'No',
  `health_status` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `Reasontosale` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `pet_photos` varchar(255) DEFAULT NULL,
  `approved` tinyint(4) NOT NULL DEFAULT 0,
  `update_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(100) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_address` varchar(100) DEFAULT NULL,
  `user_phone` varchar(100) NOT NULL,
  `user_passwords` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'user',
  `country` text DEFAULT NULL,
  `street` text DEFAULT NULL,
  `city` text DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `martial` varchar(255) DEFAULT NULL,
  `social` varchar(255) DEFAULT NULL,
  `profession` text DEFAULT NULL,
  `imgurl` varchar(255) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_email`, `user_address`, `user_phone`, `user_passwords`, `status`, `country`, `street`, `city`, `dob`, `martial`, `social`, `profession`, `imgurl`, `gender`, `created_at`) VALUES
(4, 'root', 'manbishalbanjade@gmail.com', 'tilottama-01 banbitika', '9843906797', '$2y$10$G469jTYszRj0Q4PJBqUJiufgFHA6NqhrYEfSNsJ0pV8vFPSBveAbK', 'user', 'Nepal', 'magartole', 'butwal', '2004-04-02', 'single', 'www.facebook.com', 'student', 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1737170868/wvlliobhoumkult9dbop.jpg', 'male', '2024-12-08 10:25:04'),
(5, 'Rubi Ale', 'manbishalbanjade07@gmail.com', 'tilottama-02 banbitika', '9816495566', '$2y$10$/MMwZ352AGpgtLxgsVdeGOPVsSWFKcn.WUckCoWXV4TMMcaSJeKfm', 'user', '', '', '', '', '', '', '', 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1735306691/lk9bngzfhd9zynlk0zzg.jpg', '', '2024-12-08 10:25:04'),
(7, 'Monkey D Luffy', 'petfindera@gmail.com', 'butwal,milanchowk', '9843906797', '$2y$10$73E2nT3MzQDaBuZ6UuNLzugnkQwG5/eGXEf.aeSk93jdRhxz9jcsm', 'admin', '', '', '', '', '', '', '', 'https://res.cloudinary.com/di6s2rhtn/image/upload/v1737171678/edd093yk24oxwcivqsb2.jpg', '', '2024-12-08 16:55:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_pets`
--
ALTER TABLE `add_pets`
  ADD PRIMARY KEY (`pet_id`),
  ADD KEY `owner_id` (`owner_id`);

--
-- Indexes for table `adopter`
--
ALTER TABLE `adopter`
  ADD PRIMARY KEY (`adopt_id`),
  ADD KEY `pet_id` (`pet_id`),
  ADD KEY `adopter_id` (`adopter_id`);

--
-- Indexes for table `traffic_logs`
--
ALTER TABLE `traffic_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `update_pet`
--
ALTER TABLE `update_pet`
  ADD PRIMARY KEY (`update_id`),
  ADD KEY `pet_id` (`pet_id`),
  ADD KEY `owner_id` (`owner_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_pets`
--
ALTER TABLE `add_pets`
  MODIFY `pet_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `adopter`
--
ALTER TABLE `adopter`
  MODIFY `adopt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `traffic_logs`
--
ALTER TABLE `traffic_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=147;

--
-- AUTO_INCREMENT for table `update_pet`
--
ALTER TABLE `update_pet`
  MODIFY `update_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `add_pets`
--
ALTER TABLE `add_pets`
  ADD CONSTRAINT `add_pets_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `users` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `adopter`
--
ALTER TABLE `adopter`
  ADD CONSTRAINT `adopter_ibfk_1` FOREIGN KEY (`adopter_id`) REFERENCES `users` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `adopter_ibfk_2` FOREIGN KEY (`pet_id`) REFERENCES `add_pets` (`pet_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `traffic_logs`
--
ALTER TABLE `traffic_logs`
  ADD CONSTRAINT `traffic_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `update_pet`
--
ALTER TABLE `update_pet`
  ADD CONSTRAINT `update_pet_ibfk_1` FOREIGN KEY (`pet_id`) REFERENCES `add_pets` (`pet_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `update_pet_ibfk_2` FOREIGN KEY (`owner_id`) REFERENCES `users` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
