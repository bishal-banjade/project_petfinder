<?php
// Database connection
include('db2.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Get the form input
  $userId = $conn->real_escape_string($_POST['userId']);
  $userName = $conn->real_escape_string($_POST['userName']);
  $userPhone = $conn->real_escape_string($_POST['userPhone']);
  $userEmail = $conn->real_escape_string($_POST['userEmail']);
  $userPassword = password_hash($conn->real_escape_string($_POST['userPassword']), PASSWORD_DEFAULT); // Hash the password
  $userAddress = $conn->real_escape_string($_POST['userAddress']); // New address field

  // Insert the new user into the database
  $sql = "INSERT INTO users (user_id, user_name, user_phone, user_email, password, user_address) 
            VALUES ('$userId', '$userName', '$userPhone', '$userEmail', '$userPassword', '$userAddress')";

  if ($conn->query($sql) === TRUE) {
    header("Location: admindashboard.php?success=1"); // Redirect to the same page
    exit();
  } else {
    echo "Error: " . $conn->error; // Display error message
  }
}

// Fetch existing users
$sql1 = "SELECT user_id, user_name, user_phone, user_email, user_address FROM users WHERE status='user';";
$result = $conn->query($sql1);


$newMessagesResult = $conn->query("SELECT COUNT(*) as total FROM add_pets WHERE upload = 0");
$newMessages = $newMessagesResult->fetch_assoc()['total'];

// Fetch successful transactions (success = 1)
$successfulTransactionsResult = $conn->query("SELECT COUNT(*) as total FROM add_pets WHERE success = 1 AND payment = 0");
$successfulTransactions = $successfulTransactionsResult->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
  <title>PetFinder Admin Panel</title>
  <link rel="stylesheet" href="admin.css?v=<?php echo time(); ?>" />
  <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css" />
  <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css" />
  <script src="https://kit.fontawesome.com/0cf1d61e41.js" crossorigin="anonymous"></script>

  <style>
    :root {
      --green: #00e77f;
      --white: #fff;
      --light-white: #aaa;
      --black: #3d3d3d;
      --light-bg: #4b4b4b;
      --grey-bg: #f0f0f0;
      --light-green: rgba(0, 231, 127, 0.3);
    }

    * {
      font-family: "Poppins", sans-serif;
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    .modal {
      display: none;
      position: fixed;
      z-index: 1000;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgba(0, 0, 0, 0.5);
    }

    .modal-content {
      background-color: var(--light-bg);
      margin: 15% auto;
      padding: 2rem;
      border: 2px solid var(--light-green);
      border-radius: 0.5rem;
      width: 90%;
      max-width: 500px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
    }

    .close {
      color: var(--white);
      float: right;
      font-size: 28px;
      font-weight: bold;
    }

    .close:hover,
    .close:focus {
      color: var(--green);
      text-decoration: none;
      cursor: pointer;
    }

    h2 {
      margin-bottom: 1rem;
      font-size: 1.8rem;
      color: var(--white);
      text-align: center;
    }

    .form-group {
      margin-bottom: 1rem;
      text-align: left;
    }

    .form-group label {
      display: block;
      margin-bottom: 0.3rem;
      font-size: 1.1rem;
      color: var(--light-white);
    }

    .form-group input {
      width: 100%;
      padding: 0.4rem;
      border: 1px solid var(--light-white);
      border-radius: 0.5rem;
      background-color: transparent;
      color: var(--white);
      font-size: 1.2rem;
      transition: border 0.3s;
    }

    .form-group input:focus {
      border: 1px solid var(--green);
      outline: none;
    }

    button[type="submit"] {
      background-color: var(--green);
      color: var(--white);
      padding: 0.5rem;
      border: none;
      border-radius: 5rem;
      cursor: pointer;
      font-size: 1.2rem;
      transition: background-color 0.3s;
      width: 100%;
    }

    .header-menu .user .home-button span {
      margin-right: 0.5rem;
      /* Space between icon and text */
      font-size: 1.5rem;
      /* Adjust size as needed */
    }

    button[type="submit"]:hover {
      background-color: var(--white);
      color: var(--black);
    }

    @media (max-width: 450px) {
      .modal-content {
        padding: 1.5rem;
      }

      h2 {
        font-size: 1.6rem;
      }
    }
  </style>
</head>

<body>
  <?php include 'adminnav.php' ?>






  <main>
    <div class="page-header">
      <h1>User Management</h1>
      <small>Home / User Management</small>
    </div>
    <div class="page-content">
      <div class="records table-responsive">
        <div class="record-header">
          <div class="add">
            <span>Entries</span>
            <select id="entries-per-page" onchange="updateEntriesPerPage()">
              <option value="10" <?php echo (isset($_GET['entries']) && $_GET['entries'] == 10) ? 'selected' : ''; ?>>10</option>
              <option value="20" <?php echo (isset($_GET['entries']) && $_GET['entries'] == 20) ? 'selected' : ''; ?>>20</option>
              <option value="50" <?php echo (isset($_GET['entries']) && $_GET['entries'] == 50) ? 'selected' : ''; ?>>50</option>
            </select>
            <button onclick="openAddRecordModal()">Add Record</button>
          </div>
        </div>
        <div class="user-management-table">
          <table id="userTable">
            <thead>
              <tr>
                <th>User ID</th>
                <th>User Name</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Address</th>
                <th>Total Posts</th> <!-- New column for total posts -->
                <th>Actions</th>
              </tr>
            </thead>
            <tbody id="userTableBody">
              <?php
              // Fetch user data with total posts
              $entriesPerPage = isset($_GET['entries']) ? (int)$_GET['entries'] : 10;
              $sql3 = "
    SELECT u.user_id, u.user_name, u.user_phone, u.user_email, u.user_address, COUNT(p.pet_id) AS total_posts
    FROM users u
    LEFT JOIN add_pets p ON u.user_id = p.owner_id AND p.upload = 1
    GROUP BY u.user_id
    LIMIT $entriesPerPage
";
              $result = $conn->query($sql3);
              while ($row = $result->fetch_assoc()): ?>
                <tr>
                  <td><?php echo htmlspecialchars($row['user_id']); ?></td>
                  <td><?php echo htmlspecialchars($row['user_name']); ?></td>
                  <td><?php echo htmlspecialchars($row['user_phone']); ?></td>
                  <td><?php echo htmlspecialchars($row['user_email']); ?></td>
                  <td><?php echo htmlspecialchars($row['user_address']); ?></td>
                  <td><?php echo htmlspecialchars($row['total_posts']); ?></td> <!-- Display total posts -->
                  <td>
                    <a href="view_posts.php?user_id=<?php echo htmlspecialchars($row['user_id']); ?>" title="View Posts">
                      <i class="fa-solid fa-eye"></i>
                    </a>
                    <a href="delete_user.php?user_id=<?php echo htmlspecialchars($row['user_id']); ?>" title="Delete User" onclick="return confirm('Are you sure you want to delete this user?');">
                      <i class="fa-solid fa-trash"></i>
                    </a>
                  </td>
                </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </main>
  </div>

  <!-- Modal for adding a new record -->
  <div id="addRecordModal" class="modal">
    <div class="modal-content">
      <span class="close" onclick="closeAddRecordModal()">&times;</span>
      <h2>Add New User</h2>
      <form id="addRecordForm" method="POST" action="admindashboard.php" onsubmit="return validateForm()">
        <div class="form-group">
          <label for="userId">User ID:</label>
          <input type="text" id="userId" name="userId" required>
        </div>
        <div class="form-group">
          <label for="userName">User Name:</label>
          <input type="text" id="userName" name="userName" required>
        </div>
        <div class="form-group">
          <label for="userPhone">User Phone:</label>
          <input type="tel" id="userPhone" name="userPhone" required>
        </div>
        <div class="form-group">
          <label for="userEmail">Email:</label>
          <input type="email" id="userEmail" name="userEmail" required>
        </div>
        <div class="form-group">
          <label for="userAddress">Address:</label>
          <input type="text" id="userAddress" name="userAddress" required>
        </div>
        <div class="form-group">
          <label for="userPassword">Password:</label>
          <input type="password" id="userPassword" name="userPassword" required>
        </div>
        <button type="submit">Create User</button>
      </form>
    </div>
  </div>

  <script>
    function openAddRecordModal() {
      document.getElementById('addRecordModal').style.display = 'block';
    }

    function closeAddRecordModal() {
      document.getElementById('addRecordModal').style.display = 'none';
    }

    function validateForm() {
      const userId = document.getElementById('userId').value;
      const userName = document.getElementById('userName').value;
      const userPhone = document.getElementById('userPhone').value;
      const userEmail = document.getElementById('userEmail').value;
      const userAddress = document.getElementById('userAddress').value;
      const userPassword = document.getElementById('userPassword').value;

      if (!userId || !userName || !userPhone || !userEmail || !userAddress || !userPassword) {
        alert("All fields are required!");
        return false;
      }
      return true;
    }

    function updateEntriesPerPage() {
      const select = document.getElementById('entries-per-page');
      const selectedValue = select.value;
      window.location.href = window.location.pathname + '?entries=' + selectedValue;
    }
  </script>
  </main>
</body>

</html>