<?php
include('db.php');

$userId = $_SESSION['user_id'];

$sql = "
    SELECT 
        add_pets.* 
    FROM 
        add_pets 
    WHERE 
        upload = 1 and success=0
";
$conditions = [];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['breed']) && !empty($_GET['breed'])) {
        $filterBreed = mysqli_real_escape_string($conn, $_GET['breed']);
        $conditions[] = "pet_breed='$filterBreed'";
    }
    if (isset($_GET['age']) && !empty($_GET['age'])) {
        $filterAge = (int)$_GET['age'];
        $conditions[] = "age<='$filterAge'";
    }
    if (isset($_GET['category']) && !empty($_GET['category'])) {
        $filterCategory = mysqli_real_escape_string($conn, $_GET['category']);
        $conditions[] = "pet_category='$filterCategory'";
    }
    if (isset($_GET['price']) && !empty($_GET['price'])) {
        $filterPrice = (int)$_GET['price'];
        $conditions[] = "price<='$filterPrice'";
    }
}

if (count($conditions) > 0) {
    $sql .= " AND " . implode(' AND ', $conditions);
}

$petdel = $conn->query($sql);

if (!$petdel) {
    die("Query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Find Pets</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="search.css">
    <script src="https://kit.fontawesome.com/524c5a650e.js" crossorigin="anonymous"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        nav {
            background: #35424a;
            padding: 10px 8px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        nav .bton {
            display: flex;
            flex-grow: 1;
        }

        nav input[type="text"] {
            padding: 10px;
            border: none;
            border-radius: 5px 0 0 5px;
            flex-grow: 1;
        }

        nav button.src {
            background: #e8491d;
            border: none;
            padding: 10px;
            border-radius: 0 5px 5px 0;
            color: white;
            cursor: pointer;
        }

        nav button.src:hover {
            background: #c6391a;
        }

        .bton {
            margin-left: 30rem;
        }

        .filter {
            margin: 20px;
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
        }

        .filter select {
            padding: 10px;
            margin: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
            flex: 1 1 200px;
        }

        .filter button.filt {
            padding: 10px 20px;
            background: #e8491d;
            border: none;
            border-radius: 5px;
            color: white;
            cursor: pointer;
        }

        .filter button.filt:hover {
            background: #c6391a;
        }

        .msg {
            height: 40vh;
            width: 100vw;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .msg1 {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .msg1 img {
            width: 200px;
            opacity: 0.4;
            margin: 4px;
        }

        .msg p {
            text-align: center;
            font-size: 20px;
            color: #151515aa;
        }

        @media (max-width: 600px) {
            nav {
                flex-direction: column;
                align-items: stretch;
            }

            nav .bton {
                margin-left: 0;
                margin-top: 10px;
            }

            .filter {
                flex-direction: column;
                align-items: stretch;
                margin: 10px;
            }

            .filter select {
                margin-bottom: 10px;
                width: 100%;
            }

            .filter button.filt {
                width: 100%;
            }

            .msg {
                flex-direction: column;
                height: auto;
                padding: 20px;
            }

            .msg1 img {
                width: 150px;
            }

            .msg p {
                font-size: 18px;
            }
        }

        @media (max-width: 400px) {
            nav {
                padding: 5px;
            }

            nav input[type="text"] {
                padding: 8px;
            }

            nav button.src {
                padding: 8px;
            }

            .filter button.filt {
                padding: 8px 10px;
            }

            .msg p {
                font-size: 16px;
            }
        }
    </style>
</head>

<body>
    <nav>
        <div class="filter">
            <form action="" method="GET">
                <select name="breed">
                    <option value="" disabled selected>Select Breed</option>

                    <option value="Labrador">Labrador</option>
                    <option value="German Shepherd">German Shepherd</option>
                    <option value="Golden Retriever">Golden Retriever</option>
                    <option value="Bulldog">Bulldog</option>
                    <option value="Beagle">Beagle</option>
                    <option value="Poodle">Poodle</option>
                    <option value="Rottweiler">Rottweiler</option>
                    <option value="Dachshund">Dachshund</option>
                    <option value="French Bulldog">French Bulldog</option>
                    <option value="Yorkshire Terrier">Yorkshire Terrier</option>
                    <!-- Cat Breeds -->
                    <option value="Siamese">Siamese</option>
                    <option value="Persian">Persian</option>
                    <option value="Maine Coon">Maine Coon</option>
                    <option value="Ragdoll">Ragdoll</option>
                    <option value="Bengal">Bengal</option>
                    <option value="Sphynx">Sphynx</option>
                    <option value="Scottish Fold">Scottish Fold</option>
                    <option value="Abyssinian">Abyssinian</option>
                    <option value="British Shorthair">British Shorthair</option>
                    <option value="American Shorthair">American Shorthair</option>
                </select>

                <select name="age">
                    <option value="" disabled selected>Select Age</option>
                    <option value="1">1 Year</option>
                    <option value="2">2 Years</option>
                    <option value="3">3 Years</option>
                    <option value="4">4 Years</option>
                    <option value="5">5+ Years</option>
                </select>

                <select name="category">
                    <option value="" disabled selected>Select Category</option>
                    <option value="Dog">Dog</option>
                    <option value="Cat">Cat</option>
                    <option value="Fish">Fish</option>
                    <option value="Tortoise">Tortoise</option>
                    <option value="Mouse">Mouse</option>
                </select>

                <select name="price">
                    <option value="" disabled selected>Select Price</option>
                    <option value="5">Up to 5</option>
                    <option value="10">Up to 10</option>
                    <option value="150">Up to 150</option>
                    <option value="200">200+</option>
                </select>

                <button class="filt" type="submit">Filter</button>
            </form>
        </div>
        <div class="bton">
            <form method="POST">
                <input id="tags" type="text" name="search" placeholder="Search for pets..." required>
                <button class="src" type="submit" name="searchitem"><i class="fa-solid fa-magnifying-glass"></i></button>
            </form>
        </div>
    </nav>
    <div class="pet-cart1">
        <?php

        if (isset($_POST['searchitem'])) {
            $data = mysqli_real_escape_string($conn, $_POST['search']);
            $qry = "SELECT * FROM add_pets WHERE CONCAT(pet_breed, pet_name, pet_category) LIKE '%$data%'";
            $result = mysqli_query($conn, $qry);
            if ($result) {
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $isOwner = ($row['owner_id'] == $userId);
        ?>
                        <div class="pet-item" onclick="window.location.href='pet_details.php?id=<?php echo htmlspecialchars($row['pet_id']); ?>'">
                            <img src="<?php echo htmlspecialchars($row["pet_photos"]); ?>" alt="Pet Photo" class="pet-photo" />
                            <div class="pet-info">
                                <h3 class="pet-name"><strong>Name:</strong> <?php echo htmlspecialchars($row['pet_name']); ?></h3>
                                <p class="pet-breed"><strong>Species:</strong> <?php echo htmlspecialchars($row['pet_category']); ?></p>
                                <p class="pet-age"><strong>Age:</strong> <?php echo htmlspecialchars($row['age']); ?> Years</p>
                                <span><strong>Price:</strong></span>
                                <span class="pet-price">Rs. <?php echo htmlspecialchars($row['price']); ?></span>
                                <div class="pet-buttons">
                                    <button class="btn-details" onclick="window.location.href='pet_details.php?id=<?php echo htmlspecialchars($row['pet_id']); ?>'">Details</button>
                                    <button class="btn-adopt"
                                        onclick="event.stopPropagation(); window.location.href='adopt.php?id=<?php echo htmlspecialchars($row['pet_id']); ?>'"
                                        <?php if ($isOwner) echo 'disabled'; ?>
                                        title="<?php if ($isOwner) echo 'You cannot adopt your own pet.'; ?>">
                                        Adopt
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php
                    }
                } else {
                    echo '<p>No results found for "' . htmlspecialchars($data) . '"</p>';
                }
            }
        } else {

            if (mysqli_num_rows($petdel) > 0) {
                while ($row = mysqli_fetch_assoc($petdel)) {
                    $isOwner = ($row['owner_id'] == $userId);
                    ?>
                    <div class="pet-item" onclick="window.location.href='pet_details.php?id=<?php echo htmlspecialchars($row['pet_id']); ?>'">
                        <img src="<?php echo htmlspecialchars($row["pet_photos"]); ?>" alt="Pet Photo" class="pet-photo" />
                        <div class="pet-info">
                            <h3 class="pet-name"><strong>Name:</strong> <?php echo htmlspecialchars($row['pet_name']); ?></h3>
                            <p class="pet-breed"><strong>Species:</strong> <?php echo htmlspecialchars($row['pet_category']); ?></p>
                            <p class="pet-age"><strong>Age:</strong> <?php echo htmlspecialchars($row['age']); ?> Years</p>
                            <span><strong>Price:</strong></span>
                            <span class="pet-price">Rs. <?php echo htmlspecialchars($row['price']); ?></span>
                            <div class="pet-buttons">
                                <button class="btn-details" onclick="window.location.href='pet_details.php?id=<?php echo htmlspecialchars($row['pet_id']); ?>'">Details</button>
                                <button class="btn-adopt"
                                    onclick="event.stopPropagation(); window.location.href='adopt.php?id=<?php echo htmlspecialchars($row['pet_id']); ?>'"
                                    <?php if ($isOwner) echo 'disabled'; ?>
                                    title="<?php if ($isOwner) echo 'You cannot adopt your own pet.'; ?>">
                                    Adopt
                                </button>
                            </div>
                        </div>
                    </div>
        <?php
                }
            } else {

                $filterMessage = '';
                if (!empty($conditions)) {
                    $filterMessage = implode(', ', array_map(function ($cond) {
                        return htmlspecialchars($cond);
                    }, $conditions));
                }
                echo '
        <div class="msg">
        <div class="msg1">
            <img src="sad.png" alt="No results">
            <p class="nores">No results found for the filters: ' . $filterMessage . '.</p>
        </div>
        </div>
    ';
            }
        }
        ?>
    </div>
</body>

</html>