<?php

session_start();
if (empty($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
include('db.php');
$user_email = $_SESSION['useremail'];


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';
if (isset($_GET['pet_id'])) {
    $petId = $_GET['pet_id'];

    $sql = "DELETE FROM add_pets where pet_id='$petId'";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'finderpet275@gmail.com';
        $mail->Password = 'oydy pijk bjal hdci';
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;

        $mail->setFrom('finderpet275@gmail.com');
        $mail->addAddress($user_email);
        $mail->isHTML(true);
        $mail->Subject = "[FindRoom Post Approvement]";
        $mail->Body = "<p>Dear " . $username . ", your post update for [ID:" . $id . "] has been rejected by the admin due to certain unmatched condition or violation of website policy.<br>Please contact to the admin for further information.<br><br>Thank you<br>findroom.com</p>";
        $mail->send();
        header("Location:admin.php");
    }
}
