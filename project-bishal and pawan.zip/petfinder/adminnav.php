 <!DOCTYPE html>
 <html lang="en">

 <head>
     <meta charset="UTF-8" />
     <meta
         name="viewport"
         content="width=device-width, initial-scale=1, maximum-scale=1" />
     <title>petfinder</title>
     <link rel="stylesheet" href="admin.css ?v=>?php echo time();?>" />

     <link
         rel="stylesheet"
         href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css" />
     <script
         src="https://kit.fontawesome.com/0cf1d61e41.js"
         crossorigin="anonymous"></script>
 </head>


 <body>



     <input type="checkbox" id="menu-toggle" />
     <div class="sidebar">
         <div class="side-header">
             <h3>pet<span>Finder</span></h3>
         </div>
         <div class="side-content">
             <div class="profile">
                 <div class="profile-img"></div>
                 <h4>Admin</h4>
                 <small>Pet Association Manager</small>
             </div>
             <div class="side-menu">
                 <ul>
                     <li>
                         <a href="./admindashboard.php">
                             <span class="las la-home"></span>
                             <small>Dashboard</small>
                         </a>
                     </li>
                     <li>
                         <a href="./adminprofile.php">
                             <span class="fa-solid fa-user"></span>
                             <small>Profile</small>
                         </a>
                     </li>
                     <li>
                         <a href="./adminpostpending.php">
                             <span class="fa-regular fa-hourglass-half"></span>
                             <small>Pending Post</small>
                         </a>
                     </li>
                     <li>
                         <a href="./petmanagement.php">
                             <span class="fa-solid fa-paw"></span>
                             <small>pet Management</small>
                         </a>
                     </li>

                     <li>
                         <a href="./logout.php">
                             <span class="fa-solid fa-right-from-bracket"></span>
                             <small>Logout</small>
                         </a>
                     </li>
                 </ul>
             </div>
         </div>
     </div>

     <div class="main-content">
         <header class="header">
             <div class="header-content">
                 <label for="menu-toggle">
                     <span class="las la-bars"></span>
                 </label>
             </div>
             <div class="header-menu">
                 <div class="notify-icon">
                     <span class="las la-envelope"></span>
                     <span class="notify"><?php echo $newMessages; ?></span>
                 </div>
                 <div class="notify-icon">
                     <span class="las la-bell"></span>
                     <span class="notify"><?php echo $successfulTransactions; ?></span>
                 </div>
                 <div class="user">
                     <div class="bg-img" style="background-image: url('img/1.jpeg')"></div>
                     <a href="admin.php" class="home-button">
                         <span class="las la-home"></span> Home
                     </a>
                 </div>
             </div>
         </header>