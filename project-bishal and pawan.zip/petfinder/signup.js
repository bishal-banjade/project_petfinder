document
  .getElementById("signup-form")
  .addEventListener("submit", function (event) {
    event.preventDefault();

    const fullName = document.getElementById("full-name").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirm-password").value;
    const phone = document.getElementById("phone").value.trim();
    const terms = document.getElementById("terms").checked;

    if (!fullName || !email || !password || !confirmPassword || !phone) {
      alert("Please fill in all required fields.");
      return;
    }

    const emailPattern = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;
    if (!emailPattern.test(email)) {
      alert("Please enter a valid Gmail address.");
      return;
    }

    if (password !== confirmPassword) {
      alert("Passwords do not match. Please try again.");
      return;
    }

    const phonePattern = /^9\d{9}$/;
    if (!phonePattern.test(phone)) {
      alert("Phone number must be 10 digits long and start with 9.");
      return;
    }

    if (!terms) {
      alert("You must agree to the Terms and Conditions.");
      return;
    }
    alert(
      "Verification CODE has been sent to your registered Email ID( $email)"
    );

    this.submit();
  });
