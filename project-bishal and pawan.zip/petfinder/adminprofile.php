<?php

include('db2.php');
include('./adminnav.php');

$id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$email = $_SESSION['useremail'];
$phone = $_SESSION['phoneno'];

$sql = "SELECT * FROM users WHERE user_id=?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt, $sql)) {
    die("SQL preparation error: " . mysqli_error($conn));
}
mysqli_stmt_bind_param($stmt, "s", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $image = $row['imgurl'];
} else {
    die("Error fetching data");
}

$query1 = "SELECT COUNT(*) AS total_posts FROM add_pets WHERE upload = 1";
$resultPosts = mysqli_query($conn, $query1);
$totalPosts = $resultPosts ? mysqli_fetch_array($resultPosts)['total_posts'] : 0;

$query2 = "SELECT COUNT(*) AS total_users FROM users";
$resultUsers = mysqli_query($conn, $query2);
$totalUsers = $resultUsers ? mysqli_fetch_array($resultUsers)['total_users'] : 0;

$query3 = "SELECT COUNT(*) AS total_success_payments FROM add_pets WHERE success = 1 AND payment = 1";
$resultSuccessPayments = mysqli_query($conn, $query3);
$totalSuccessPayments = $resultSuccessPayments ? mysqli_fetch_array($resultSuccessPayments)['total_success_payments'] : 0;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Profile</title>
    <link rel="stylesheet" href="profilepage.css">
    <script src="https://kit.fontawesome.com/524c5a650e.js" crossorigin="anonymous"></script>
</head>

<body>
    <div class="main">
        <div class="readme">
            <div class="des">
                <i class="fa-regular fa-circle-user"></i> ADMIN DETAILS
            </div>
        </div>
        <div class="text">
            <div class="cover"></div>
            <div class="down">
                <div class="left">
                    <div class="camp">
                        <label class="input-file" for="input-file"><i class="fa-solid fa-camera"></i></label>
                    </div>
                    <div class="forimage">
                        <img src="<?php echo htmlspecialchars($image); ?>" alt="Admin Image">
                    </div>
                    <div class="name">
                        <h4><?php echo htmlspecialchars($username); ?></h4>
                        <p class="rl">Admin</p>
                    </div>
                    <div class="postdetails">
                        <ul>
                            <li>
                                <p>Total Posts of All Users</p><span class="blue"><?php echo htmlspecialchars($totalPosts); ?></span>
                            </li>
                            <li>
                                <p>Total Users</p><span class="yellu"><?php echo htmlspecialchars($totalUsers); ?></span>
                            </li>
                            <li>
                                <p>Total Successful Payments</p><span class="red"><?php echo htmlspecialchars($totalSuccessPayments); ?></span>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="right">
                    <div class="top">
                        <p>Account Status</p>
                    </div>
                    <div class="below">
                        <div class="r1">
                            <label class="a">Username</label>
                            <input disabled type="text" value="<?php echo htmlspecialchars($username); ?>">
                            <label class="a">Phone</label>
                            <input disabled type="text" value="<?php echo htmlspecialchars($phone); ?>">
                            <label class="a">Email Address</label>
                            <input disabled type="text" value="<?php echo htmlspecialchars($email); ?>">
                        </div>
                    </div>
                    <div class="last">
                        <button href='javascript:void()' onclick='update()'>Edit Profile</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        function update() {
            document.location.href = `adminprofileedit.php`;
        }
    </script>
</body>

</html>