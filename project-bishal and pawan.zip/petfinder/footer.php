<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        footer {
            background-color: #141d28de;

            color: var(--color-white);
            padding: 20px;
            text-align: center;
            box-shadow: 2px solid var(--color-red);

        }

        .footer-container {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
        }

        .footer-container div {
            margin: 10px;
        }

        .footer-links ul {
            list-style-type: none;
            padding: 0;
        }

        .footer-links a,
        .social-media a {
            color: var(--color-white);
            text-decoration: none;
        }

        .footer-bottom {
            margin-top: 20px;
            border-top: 1px solid #ccc;
            padding-top: 10px;
        }
    </style>
</head>

<body>
    <footer>
        <div class="footer-container">
            <div class="contact-info">
                <h3>Contact Us</h3>
                <p>Tilottama-06 banbitika</p>
                <p>Phone: 9843906797</p>
                <p>Email: support@example.com</p>
            </div>
            <div class="footer-links">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="/about">About Us</a></li>
                    <li><a href="/services">Services</a></li>
                    <li><a href="/privacy">Privacy Policy</a></li>
                    <li><a href="/terms">Terms of Service</a></li>
                </ul>
            </div>
            <div class="social-media">
                <h3>Follow Us</h3>
                <a href="https:
                <a href=" https:
                    <a href="https:
            </div>
            <div class=" newsletter">
                    <h3>Subscribe to Our Newsletter</h3>
                    <input type="email" placeholder="Enter your email" />
                    <button>Subscribe</button>
            </div>
        </div>
        <div class="footer-bottom">
            <p>© 2024 Pet Services. All Rights Reserved.</p>
        </div>
    </footer>
</body>

</html>