<div class="pet-cart1">
    <?php

    if (isset($_POST['searchitem'])) {
        $data = mysqli_real_escape_string($conn, $_POST['search']);
        $qry = "SELECT * FROM add_pets WHERE CONCAT(pet_breed, age, pet_category, pet_name) LIKE '%$data%'";
        $result = mysqli_query($conn, $qry);
        if ($result) {
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
    ?>
                    <div class="pet-item" onclick="window.location.href='pet_details.php?id=<?php echo htmlspecialchars($row['pet_id']); ?>'">
                        <img src="<?php echo htmlspecialchars($row["pet_photos"]); ?>" alt="Pet Photo" class="pet-photo" />
                        <div class="pet-info">
                            <h3 class="pet-name">Name: <?php echo htmlspecialchars($row['pet_name']); ?></h3>
                            <p class="pet-breed">Species: <?php echo htmlspecialchars($row['pet_category']); ?></p>
                            <p class="pet-age">Age: <?php echo htmlspecialchars($row['age']); ?> Years</p>
                            <p class="pet-price">Price: Rs. <?php echo htmlspecialchars($row['price']); ?></p>
                            <div class="pet-buttons">
                                <button class="btn-details" onclick="window.location.href='pet_details.php?id=<?php echo htmlspecialchars($row['pet_id']); ?>'">Details</button>
                                <button class="btn-adopt" onclick="event.stopPropagation(); window.location.href='adopt.php?id=<?php echo htmlspecialchars($row['pet_id']); ?>'">Adopt</button>
                            </div>
                        </div>
                    </div>
                <?php
                }
            } else {
                echo '<p>No results found for "' . htmlspecialchars($data) . '"</p>';
            }
        }
    } else {

        if (mysqli_num_rows($petdel) > 0) {
            while ($row = mysqli_fetch_assoc($petdel)) {
                ?>
                <div class="pet-item" onclick="window.location.href='pet_details.php?id=<?php echo htmlspecialchars($row['pet_id']); ?>'">
                    <img src="<?php echo htmlspecialchars($row["pet_photos"]); ?>" alt="Pet Photo" class="pet-photo" />
                    <div class="pet-info">
                        <h3 class="pet-name">Name: <?php echo htmlspecialchars($row['pet_name']); ?></h3>
                        <p class="pet-breed">Species: <?php echo htmlspecialchars($row['pet_category']); ?></p>
                        <p class="pet-age">Age: <?php echo htmlspecialchars($row['age']); ?> Years</p>
                        <p class="pet-price">Price: Rs. <?php echo htmlspecialchars($row['price']); ?></p>
                        <div class="pet-buttons">
                            <button class="btn-details" onclick="window.location.href='pet_details.php?id=<?php echo htmlspecialchars($row['pet_id']); ?>'">Details</button>
                            <button class="btn-adopt" onclick="event.stopPropagation(); window.location.href='adopt.php?id=<?php echo htmlspecialchars($row['pet_id']); ?>'">Adopt</button>
                        </div>
                    </div>
                </div>
    <?php
            }
        } else {
            echo '<p>No pets available.</p>';
        }
    }
    ?>
</div>