<?php
include 'db.php';
require 'vendor/autoload.php';
include './nav2.php';

use Cloudinary\Cloudinary;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Dotenv\Dotenv;

require 'phpmailer/Exception.php';
require 'phpmailer/PHPMailer.php';
require 'phpmailer/SMTP.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->load();

$cloudinary = new Cloudinary(array(
    "cloud" => array(
        "cloud_name" => 'di6s2rhtn',
        "api_key" => '887923495746756',
        "api_secret" => '9Sh2np6pxJGbiKdA2H_4Kb-k3b4',
    )
));

if (isset($_GET['id'])) {
    $petId = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT * FROM add_pets WHERE pet_id = ?");
    $stmt->bind_param("i", $petId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $pet = $result->fetch_assoc();
    } else {
        die("Pet not found.");
    }
} else {
    die("Pet ID not specified.");
}

if (isset($_POST['submit'])) {
    if (!isset($user_id)) {
        die("User ID is not set.");
    }

    // Validate and sanitize inputs
    $adopterName = trim($_POST['full_name']);
    $adopterEmail = filter_var(trim($_POST['contact_email']), FILTER_VALIDATE_EMAIL);
    $adopterContact = trim($_POST['phone_number']);
    $adopterLocation = trim($_POST['address']);
    $adoptReason = trim($_POST['adoption_reason']);
    $city = trim($_POST['city']);
    $state = trim($_POST['state']);
    $country = trim($_POST['country']);
    $ownPets = trim($_POST['own_pets']);
    $vetName = trim($_POST['vet_name']);
    $homeStatus = $_POST['home_status'];
    $yard = $_POST['yard'];
    $children = trim($_POST['children']);
    $hoursAlone = intval($_POST['hours_alone']);

    $animalCrime = isset($_POST['animal_crime']) ? trim($_POST['animal_crime']) : '';
    $condition = isset($_POST['agree']) ? 1 : 0;

    // Check for required fields
    if (empty($adopterName) || !$adopterEmail || empty($adopterContact) || empty($adopterLocation) || empty($adoptReason)) {
        die("All fields are required.");
    }

    // Image upload for adopter photo
    $adopterPhotoUrl = null;
    if (isset($_FILES["adopter_image"]) && $_FILES["adopter_image"]["error"] == UPLOAD_ERR_OK) {
        $fileMimeType = mime_content_type($_FILES["adopter_image"]["tmp_name"]);
        if (strpos($fileMimeType, 'image') === 0) {
            try {
                $result = $cloudinary->uploadApi()->upload($_FILES["adopter_image"]["tmp_name"]);
                $adopterPhotoUrl = $result['secure_url'];
            } catch (Exception $e) {
                die("Error uploading image: " . htmlspecialchars($e->getMessage()));
            }
        } else {
            die("Uploaded file is not an image.");
        }
    } else {
        die("No file uploaded or there was an upload error.");
    }

    // Citizenship document uploads
    $citizenshipFrontUrl = uploadDocument('citizenship_front', $cloudinary);
    $citizenshipBackUrl = uploadDocument('citizenship_back', $cloudinary);

    // Check if user has already applied for the pet
    $checkStmt = $conn->prepare("SELECT * FROM adopter WHERE adopter_id = ? AND pet_id = ?");
    $checkStmt->bind_param("ii", $user_id, $petId);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

    if ($checkResult->num_rows > 0) {
        echo "<script>alert('You have already applied for this pet.');</script>";
    } else {
        // Insert adopter data into the database
        $stmt = $conn->prepare("INSERT INTO adopter (

pet_id,

adopter_id,

adopter_name,

adopter_email,

Adopter_reason,

adopter_phone,

Address,

city,

state,

country,

own_pets,

vet_name,

home_status,

yard,

children,

hours_alone,

animal_crime,

adopter_photo,

agree_condition,

D_front,

D_back

) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)");

        $stmt->bind_param(

            "iisssisssssssssssssss",

            $petId,

            $user_id,

            $adopterName,

            $adopterEmail,

            $adoptReason,

            $adopterContact,

            $adopterLocation,

            $city,

            $state,

            $country,

            $ownPets,

            $vetName,

            $homeStatus,

            $yard,

            $children,

            $hoursAlone,

            $animalCrime,

            $adopterPhotoUrl,

            $condition,

            $citizenshipFrontUrl,

            $citizenshipBackUrl

        );

        if (!$stmt->execute()) {
            die("Error inserting adopter data: " . htmlspecialchars($stmt->error));
        }

        // Send email to owner
        $ownerEmailStmt = $conn->prepare("SELECT owner_email FROM add_pets WHERE pet_id = ?");
        $ownerEmailStmt->bind_param("i", $petId);
        $ownerEmailStmt->execute();
        $ownerEmailResult = $ownerEmailStmt->get_result();

        if ($ownerEmailResult->num_rows > 0) {
            $ownerEmail = $ownerEmailResult->fetch_assoc()['owner_email'];
            sendEmail($ownerEmail, $adopterName, $adopterEmail, $pet['pet_name'], $petId, [
                'phone' => $adopterContact,
                'address' => $adopterLocation,
                'city' => $city,
                'state' => $state,
                'country' => $country,
                'reason' => $adoptReason,
                'own_pets' => $ownPets,
                'vet_name' => $vetName,
                'home_status' => $homeStatus,
                'yard' => $yard,
                'children' => $children,
                'hours_alone' => $hoursAlone,
                'animal_crime' => $animalCrime,
            ]);
        } else {
            echo "<script>alert('Owner email not found.');</script>";
        }
    }
}

$conn->close();

function uploadDocument($fieldName, $cloudinary)
{
    if (isset($_FILES[$fieldName]) && $_FILES[$fieldName]["error"] == UPLOAD_ERR_OK) {
        $fileMimeType = mime_content_type($_FILES[$fieldName]["tmp_name"]);
        if (strpos($fileMimeType, 'image') === 0) {
            try {
                $result = $cloudinary->uploadApi()->upload($_FILES[$fieldName]["tmp_name"]);
                return $result['secure_url'];
            } catch (Exception $e) {
                die("Error uploading document: " . htmlspecialchars($e->getMessage()));
            }
        } else {
            die("Uploaded file is not an image.");
        }
    }
    return null;
}

function sendEmail($ownerEmail, $adopterName, $adopterEmail, $petName, $petId, $adopterDetails)
{
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'finderpet275@gmail.com';
        $mail->Password = 'oydy pijk bjal hdci';
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;

        $mail->setFrom($adopterEmail, $adopterName);
        $mail->addAddress($ownerEmail);

        $mail->isHTML(true);
        $mail->Subject = 'New Adoption Request from ' . $adopterName;
        $mail->Body = "
            <p>You have received a new adoption request!</p>
            <p><strong>Adopter Name:</strong> {$adopterName}</p>
            <p><strong>Adopter Email:</strong> {$adopterEmail}</p>
            <p><strong>Pet Name:</strong> {$petName}</p>
            <p><strong>Phone Number:</strong> {$adopterDetails['phone']}</p>
            <p><strong>Address:</strong> {$adopterDetails['address']}</p>
            <p><strong>City:</strong> {$adopterDetails['city']}</p>
            <p><strong>State:</strong> {$adopterDetails['state']}</p>
            <p><strong>Country:</strong> {$adopterDetails['country']}</p>
            <p><strong>Reason for Adoption:</strong> {$adopterDetails['reason']}</p>
            <p><strong>Do you own pets?:</strong> {$adopterDetails['own_pets']}</p>
            <p><strong>Veterinarian's Name:</strong> {$adopterDetails['vet_name']}</p>
            <p><strong>Home Status:</strong> {$adopterDetails['home_status']}</p>
            <p><strong>Yard:</strong> {$adopterDetails['yard']}</p>
            <p><strong>Children in Home:</strong> {$adopterDetails['children']}</p>
            <p><strong>Hours Alone:</strong> {$adopterDetails['hours_alone']}</p>
            <p><strong>Animal-Related Crime:</strong> {$adopterDetails['animal_crime']}</p>
            <p>Please verify the application details.</p>
        ";

        $mail->send();

        // Update the add_pets table to set dealout=1
        $updateQuery = "UPDATE add_pets SET dealout = 1 WHERE pet_id = ?";
        $stmt = $GLOBALS['conn']->prepare($updateQuery);
        $stmt->bind_param("i", $petId);
        if (!$stmt->execute()) {
            echo "<script>alert('Error updating pet status: " . htmlspecialchars($stmt->error) . "');</script>";
        }

        echo "<script>alert('Message has been sent to the owner.'); window.location.href = 'dashboard.php';</script>";
    } catch (Exception $e) {
        echo "<script>alert('Message could not be sent: " . htmlspecialchars($e->getMessage()) . "');</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Adoption Process</title>
    <link rel="stylesheet" href="./adopt.css?v=<?php echo time(); ?>">
    <script>
        function validateForm(tabId) {
            const fields = document.querySelectorAll(`#${tabId} input[required], #${tabId} select[required], #${tabId} textarea[required]`);
            let valid = true;

            fields.forEach(field => {
                if (!field.value) {
                    field.classList.add('error'); // Add error class for styling
                    valid = false;
                } else {
                    field.classList.remove('error'); // Remove error class if valid
                }
            });

            // Additional validations
            const emailField = document.getElementById('contact_email');
            const phoneField = document.getElementById('phone_number');

            if (emailField.value && !validateEmail(emailField.value)) {
                emailField.classList.add('error');
                alert('Please enter a valid email address.');
                valid = false;
            } else {
                emailField.classList.remove('error');
            }

            if (phoneField.value && !validatePhone(phoneField.value)) {
                phoneField.classList.add('error');
                alert('Phone number must be exactly 10 digits.');
                valid = false;
            } else {
                phoneField.classList.remove('error');
            }

            return valid;
        }

        function validateEmail(email) {
            const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; // Simple email validation regex
            return regex.test(email);
        }

        function validatePhone(phone) {
            const regex = /^\d{10}$/; // Only 10 digits allowed
            return regex.test(phone);
        }

        function nextTab(currentTabId, nextTabId) {
            if (validateForm(currentTabId)) {
                document.getElementById(currentTabId).classList.remove('active');
                document.getElementById(nextTabId).classList.add('active');
            } else {
                alert('Please fill in all required fields correctly.'); // Alert for user
            }
        }

        function prevTab(currentTabId, prevTabId) {
            document.getElementById(currentTabId).classList.remove('active');
            document.getElementById(prevTabId).classList.add('active');
        }

        function previewImage(event, imageId) {
            const img = document.getElementById(imageId);
            img.src = URL.createObjectURL(event.target.files[0]);
        }

        // Example function to handle the 'back' button logic
        function back() {
            // You might want to implement specific logic for the back button
        }
    </script>
</head>

<body>
    <section>
        <div class="adoptcontainer">
            <form method="post" enctype="multipart/form-data" class="form-adopted">
                <h2>Adopting <span>process........</span></h2>

                <div class="tab active" id="personalDetails">
                    <h3>Step 1: Adopter Details</h3>

                    <div class="image-upload">
                        <img id="profileImage" src="photo/download-removebg-preview.png" alt="Profile Image" />
                        <button type="button" id="button" onclick="document.getElementById('adopter_image').click();">Select Image</button>
                        <input type="file" id="adopter_image" name="adopter_image" accept="image/*" required style="display: none" onchange="previewImage(event, 'profileImage')" />
                    </div>

                    <label for="full_name">Full Name:<span style="color: red;">*</span></label>
                    <input type="text" id="full_name" name="full_name" required />

                    <label for="contact_email">Email:<span style="color: red;">*</span></label>
                    <input type="email" id="contact_email" name="contact_email" required />

                    <label for="phone_number">Phone Number:<span style="color: red;">*</span></label>
                    <input type="text" id="phone_number" name="phone_number" required />

                    <label for="address">Address:<span style="color: red;">*</span></label>
                    <input type="text" id="address" name="address" required />

                    <label for="city">City:<span style="color: red;">*</span></label>
                    <input type="text" id="city" name="city" required />

                    <label for="state">State:<span style="color: red;">*</span></label>
                    <input type="text" id="state" name="state" required />

                    <label for="country">Country:<span style="color: red;">*</span></label>
                    <select id="country" name="country" required>
                        <option value="">Please Select</option>
                        <option value="Nepal">Nepal</option>
                        <option value="USA">United States</option>
                        <option value="Canada">Canada</option>
                    </select>

                    <label>Do you own any pets?<span style="color: red;">*</span></label>
                    <div class="inline-options">
                        <input type="radio" id="pets_yes" name="own_pets" value="Yes" required onclick="toggleVetName(true)" />
                        <label for="pets_yes">Yes</label>
                        <input type="radio" id="pets_no" name="own_pets" value="No" required onclick="toggleVetName(false)" />
                        <label for="pets_no">No</label>
                    </div>

                    <div id="vetNameContainer" style="display: none;">
                        <label for="vet_name">Veterinarian's Name </label>
                        <input type="text" id="vet_name" name="vet_name" />
                    </div>

                    <label>Do you own your home?<span style="color: red;">*</span></label>
                    <div class="inline-options">
                        <input type="radio" id="home_yes" name="home_status" value="Yes" required onclick="toggleYard(true)" />
                        <label for="home_yes">Yes</label>
                        <input type="radio" id="home_no" name="home_status" value="No" required onclick="toggleYard(false)" />
                        <label for="home_no">No</label>
                    </div>

                    <div id="yardContainer" style="display: none;">
                        <label for="yard">Do you have a yard?<span style="color: red;">*</span></label>
                        <select id="yard" name="yard" required>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                    </div>

                    <label for="children">Are there children in the home?<span style="color: red;">*</span></label>
                    <input type="text" id="children" name="children" required />

                    <label for="hours_alone">How many hours per day would the pet be alone?<span style="color: red;">*</span></label>
                    <input type="text" id="hours_alone" name="hours_alone" required />

                    <label for="adoption_reason">Reason for Adoption:<span style="color: red;">*</span></label>
                    <textarea id="adoption_reason" name="adoption_reason" required></textarea>

                    <label for="animal_crime">Have you ever been convicted of an animal-related crime?<span style="color: red;">*</span></label>
                    <div class="inline-options">
                        <input type="radio" id="yes" name="animal_crime" value="Yes" required />
                        <label for="yes">Yes</label>
                        <input type="radio" id="no" name="animal_crime" value="No" required />
                        <label for="no">No</label>
                    </div>

                    <div class="button-container">
                        <button type="button" class="cancel" onclick="back();">Cancel</button>
                        <button class="samebutton" type="button" onclick="nextTab('personalDetails', 'adoptionConditions')">Next</button>
                    </div>
                </div>

                <div class="tab" id="adoptionConditions">
                    <h2>Step 2: Adoption Conditions</h2>
                    <p>Please read and accept the following conditions:</p>
                    <ol>
                        <li><strong>Long-Term Commitment:</strong> Adopters must understand that adopting a pet is a lifelong commitment requiring time, effort, and emotional investment.</li>
                        <!-- More items here -->
                    </ol>
                    <label>
                        <input type="checkbox" id="agree" name="agree" required />
                        <strong>I agree to the adoption conditions.</strong>
                    </label>
                    <div class="button-container">
                        <button type="button" class="cancel" onclick="prevTab('adoptionConditions', 'personalDetails')">Back</button>
                        <button type="button" class="samebutton" onclick="nextTab('adoptionConditions', 'additionalPhotos')">Next</button>
                    </div>
                </div>

                <div class="tab" id="additionalPhotos">
                    <h2>Step 3: Additional Photos</h2>
                    <p>Please upload your citizenship photos:</p>
                    <div class="image-upload">
                        <img id="citizenshipFrontImage" src="photo/placeholder-front.png" alt="Citizenship Front Image" />
                        <button type="button" id="buttonFront" onclick="document.getElementById('citizenship_front').click();">Select Front Image</button>
                        <input type="file" id="citizenship_front" name="citizenship_front" accept="image/*" required style="display: none" onchange="previewImage(event, 'citizenshipFrontImage')" />
                    </div>
                    <div class="image-upload">
                        <img id="citizenshipBackImage" src="photo/placeholder-back.png" alt="Citizenship Back Image" />
                        <button type="button" id="buttonBack" onclick="document.getElementById('citizenship_back').click();">Select Back Image</button>
                        <input type="file" id="citizenship_back" name="citizenship_back" accept="image/*" required style="display: none" onchange="previewImage(event, 'citizenshipBackImage')" />
                    </div>
                    <div class="button-container">
                        <button type="button" class="cancel" onclick="prevTab('additionalPhotos', 'adoptionConditions')">Back</button>
                        <button type="button" class="samebutton" onclick="nextTab('additionalPhotos', 'finalConfirmation')">Next</button>
                    </div>
                </div>

                <div class="tab" id="finalConfirmation">
                    <h2>Step 4: Confirm Adoption</h2>
                    <p>Thank you for choosing to adopt!</p>
                    <p>Please confirm your application:</p>
                    <p><strong>Name:</strong> <span id="confirmName"></span></p>
                    <p><strong>Email:</strong> <span id="confirmEmail"></span></p>
                    <p><strong>Phone:</strong> <span id="confirmPhone"></span></p>
                    <p><strong>Address:</strong> <span id="confirmAddress"></span></p>
                    <p><strong>Reason for Adoption:</strong> <span id="confirmReason"></span></p>
                    <div class="button-container">
                        <button type="button" class="cancel" onclick="prevTab('finalConfirmation', 'additionalPhotos')">Back</button>
                        <button type="submit" class="samebutton" name="submit">Submit Application</button>
                    </div>
                </div
                    </form>
        </div>
    </section>
    <?php include './footer.php' ?>
    <script>
        function populateConfirmationFields() {
            document.getElementById('confirmName').innerText = document.getElementById('full_name').value;
            document.getElementById('confirmEmail').innerText = document.getElementById('contact_email').value;
            document.getElementById('confirmPhone').innerText = document.getElementById('phone_number').value;
            document.getElementById('confirmAddress').innerText = document.getElementById('address').value;
            document.getElementById('confirmReason').innerText = document.getElementById('adoption_reason').value;
        }

        function nextTab(currentTabId, nextTabId) {
            if (validateForm(currentTabId)) {
                if (nextTabId === 'finalConfirmation') {
                    populateConfirmationFields();
                }
                document.getElementById(currentTabId).classList.remove('active');
                document.getElementById(nextTabId).classList.add('active');
            } else {
                alert('Please fill in all required fields correctly.');
            }
        }

        function toggleVetName(show) {
            const vetNameContainer = document.getElementById('vetNameContainer');
            vetNameContainer.style.display = show ? 'block' : 'none';
        }

        function toggleYard(show) {
            const yardContainer = document.getElementById('yardContainer');
            yardContainer.style.display = show ? 'block' : 'none';
        }
    </script>

</body>


</html>