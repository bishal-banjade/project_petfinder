<?php
include 'db.php';
session_start();

if (empty($_SESSION['verification_code'])) {
    die("No user data found. Please sign up again.");
}

$name = $_SESSION['user_name'];
$email = $_SESSION['user_email'];
$address = $_SESSION['user_address'];
$phone = $_SESSION['user_phone'];
$hashed_password = $_SESSION['user_password'];
$verification_code = $_SESSION['verification_code'];

$error_message = ""; // Variable to hold error messages

if (isset($_POST['verify'])) {
    $input_code = $_POST['digit1'] . $_POST['digit2'] . $_POST['digit3'] . $_POST['digit4'] . $_POST['digit5'] . $_POST['digit6'];
    $stored_code = $_SESSION['verification_code'];

    if ($input_code == $stored_code) {
        $sql = "INSERT INTO users (user_name, user_email, user_address, user_phone, user_passwords) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssss", $name, $email, $address, $phone, $hashed_password);

        if ($stmt->execute()) {
            echo "Registration successful!";
            header("Location: login.php");
            exit;
        } else {
            echo "Error registering user.";
        }
    } else {
        $error_message = "Invalid verification code."; // Set the error message
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="stylesheet" href="./verify.css" />
</head>

<body>
    <form method="post">
        <div id="verification-container">
            <div class="form-header">
                <img src="photo/logo.png" alt="Your Logo" class="logof" />
                <h1>Verify Your Email</h1>
            </div>
            <p id="paragraph">
                We’ve sent a verification code to your inbox! Please enter the code
                below to confirm your email address. Remember, the code is only valid
                for <strong>10 minutes</strong>, so don’t wait too long!
            </p>
            <?php if (!empty($error_message)): ?>
                <div class="error-message" style="color: red; margin: 10px 0;">
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>
            <div class="input-group">
                <input type="number" name="digit1" id="digit1" maxlength="1" min="0" required oninput="moveToNext(this, 'digit2')" />
                <input type="number" name="digit2" id="digit2" maxlength="1" min="0" required oninput="moveToNext(this, 'digit3')" />
                <input type="number" name="digit3" id="digit3" maxlength="1" min="0" required oninput="moveToNext(this, 'digit4')" />
                <input type="number" name="digit4" id="digit4" maxlength="1" min="0" required oninput="moveToNext(this, 'digit5')" />
                <input type="number" name="digit5" id="digit5" maxlength="1" min="0" required oninput="moveToNext(this, 'digit6')" />
                <input type="number" name="digit6" id="digit6" maxlength="1" min="0" required />
            </div>
            <div class="verification">
                <button type="submit" name="verify">Verify</button>
            </div>
            <div class="link">
                <a href="#" onclick="resendCode()">Resend Code</a>
                <a href="#" onclick="changeEmail()">Change Email</a>
            </div>
        </div>
    </form>
    <script>
        function moveToNext(current, nextId) {
            if (current.value.length > 1 || current.value < 0) {
                current.value = current.value.slice(0, 1);
            }
            if (current.value.length === 1) {
                document.getElementById(nextId).focus();
            }
        }

        function resendCode() {
            alert('A new verification code has been sent to your email!');
        }

        function changeEmail() {
            const newEmail = prompt("Please enter your new email address:");
            if (newEmail) {
                alert(`Your email has been changed to: ${newEmail}`);
            }
        }
    </script>
</body>

</html>