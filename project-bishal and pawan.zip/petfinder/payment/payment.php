<?php

include('../db.php');
session_start();

if (empty($_SESSION['user_id'])) {
    header('Location:login.php');
}
$sessionid = $_SESSION['user_id'];
$id = filter_var($sessionid, FILTER_VALIDATE_INT);
if ($id === false) {
    die('Invalid session data');
}

$id = htmlspecialchars($id);

if (isset($_GET['pet_id'])) {


    $totalamt = $_GET['pay'];
    $pet_id = $_GET['pet_id'];
} else {
    die("couldnot found");
}
$product_id = rand(1, 1000);
$_SESSION['orderpaymentid'] = $product_id;
$sql = "UPDATE add_pets SET payment_id='$product_id' WHERE pet_id='$pet_id'";
$result = mysqli_query($conn, $sql);

?>

<?php

// esewa payment integration V2 
$secretKey = "8gBm/:&EnhH.1/q";

$message = "total_amount=$totalamt,transaction_uuid=$product_id,product_code=EPAYTEST";
$sign = hash_hmac('sha256', $message, $secretKey, true);
$hashedValue = base64_encode($sign);

?>

<html>

<head>
    <script src="https://khalti.s3.ap-south-1.amazonaws.com/KPG/dist/2020.12.17.0.0.0/khalti-checkout.iffe.js"></script>
</head>

<body>
    <style>
        html {
            user-select: none;
        }

        .display {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
            height: 95vh;
        }

        .display .inner {
            max-width: 400px;
            box-sizing: border-box;
            border: 1px solid rgba(53, 52, 52, 0.557);
            border-radius: 8px;
            padding: 38px 24px;
            text-align: center;
        }

        .inner h1 {
            margin: 0px;
            color: red;
        }

        .inner .hello {
            margin: 6px;
            padding: 2px;
            font-size: 16px;
        }

        .inner .payment_method {
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .inner button {
            outline: none;
            border: none;
            cursor: pointer;
            color: #fff;
            margin: 10px 0 0 0;
            padding: 0;
            background: transparent;
        }

        .inner button img {
            border: 1px solid rgba(250, 250, 250, 0.47);
            width: 100px;
            margin: 0;
        }

        .inner button img:hover {
            border: 1px solid rgba(227, 226, 226, 0.708);
            box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.3);
            border-radius: 4px;
        }

        .inner h4 {
            margin: 0px;
            padding: 4px;
        }
    </style>
    <div class="display">
        <div class="inner">
            <h1>Transaction Alert!</h1>

            <h4>Continue to pay with</h4>

            <div class="payment_method">

                <form action="https://rc-epay.esewa.com.np/api/epay/main/v2/form" method="POST">
                    <input type="hidden" id="amount" name="amount" value="<?php echo $totalamt; ?>" required>
                    <input type="hidden" id="tax_amount" name="tax_amount" value="0" required>
                    <input type="hidden" id="total_amount" name="total_amount" value="<?php echo $totalamt; ?>" required>
                    <input type="hidden" id="transaction_uuid" name="transaction_uuid" value="<?php echo $product_id; ?>" required>
                    <input type="hidden" id="product_code" name="product_code" value="EPAYTEST" required>
                    <input type="hidden" id="product_service_charge" name="product_service_charge" value="0" required>
                    <input type="hidden" id="product_delivery_charge" name="product_delivery_charge" value="0" required>
                    <input type="hidden" id="success_url" name="success_url" value="http://localhost/PETFINDER/payment/esewapaymentsuccess.php" required>
                    <input type="hidden" id="failure_url" name="failure_url" value="http://localhost/PETFINDER/payment/esewapaymentfailed.php" required>
                    <input type="hidden" id="signed_field_names" name="signed_field_names" value="total_amount,transaction_uuid,product_code" required>
                    <input type="hidden" id="signature" name="signature" value="<?php echo $hashedValue; ?>" required>
                    <button type="submit" name="submit" id="esewa"><img src='esewa_og.webp'></button>
                </form>
            </div>
        </div>
    </div>
</body>

</html>