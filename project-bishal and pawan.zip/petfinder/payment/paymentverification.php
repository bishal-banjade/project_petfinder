<?php

include('../connect.php');
session_start();
$sessionid = $_SESSION['users'];
$id = filter_var($sessionid, FILTER_VALIDATE_INT);
if ($id === false) {
    die('Invalid session data');
}

$pid = $_SESSION['orderpaymentid'];
if(($_REQUEST['total_amount']) && ($_REQUEST['status']) && ($_REQUEST['purchase_order_id'])){
    $check = $_REQUEST['status'];
    $productid = $_REQUEST['purchase_order_id'];

    if(($check = "Completed")){
      $sql = "UPDATE postboost SET status=1 where paymentid='$productid'";
      $result = mysqli_query($conn, $sql);
      if($result){
      header('Location: paymentsuccess.php');
      return true;
      }
      else{
        echo "<script type='text/javascript'>
        alert('Something went wrong!');
        </script>";
      }
    }
    else{
      header('Location: paymentfail.php');
    }
}
?>