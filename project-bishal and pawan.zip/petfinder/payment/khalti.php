<?php
include('../connect.php');
session_start();
if(empty($_SESSION['users'])){
    header('Location:login.php');
}
$sessionid = $_SESSION['users'];
$id = filter_var($sessionid, FILTER_VALIDATE_INT);
if ($id === false) {
    die('Invalid session data');
}
$id = htmlspecialchars($id);

 // khalti payment integration V2 
 $stmt = $conn->prepare("SELECT * FROM users WHERE uid=?");
 $stmt->bind_param("i", $id);
 $stmt->execute();
 $result = $stmt->get_result();
 $row = $result->fetch_assoc();
 $name = $row['username'];
 $email = $row['email'];
 $phone = $row['phone'];
 
 if(isset($_POST['esewapay'])){
     $productid= $_POST['product_id'];
     $amount = $_POST['amount'];
     $return_url = $_POST['return_url'];
     
     $curl = curl_init();
     $data = array(
         'return_url' => $return_url,
         'website_url' => 'http://localhost/rentalapp/payment/payment.php',
         'amount' => $amount,
         'purchase_order_id' => $productid,
         'purchase_order_name' => 'test',
         'customer_info' => array(
             'name' => $name,
             'email' => $email,
             'phone' => $phone
         )
     );
     $payload = json_encode($data);
 
     curl_setopt_array($curl, array(
         CURLOPT_URL => 'https://a.khalti.com/api/v2/epayment/initiate/',
         CURLOPT_RETURNTRANSFER => true,
         CURLOPT_ENCODING => '',
         CURLOPT_MAXREDIRS => 10,
         CURLOPT_TIMEOUT => 30,
         CURLOPT_FOLLOWLOCATION => true,
         CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
         CURLOPT_CUSTOMREQUEST => 'POST',
         CURLOPT_POSTFIELDS => $payload,
         CURLOPT_HTTPHEADER => array(
             'Authorization: Key 266616deac284d8b8a72868efb75d635',
             'Content-Type: application/json',
         ),
     ));
 
     $response = curl_exec($curl);
 
     if ($response === false) {
         echo "Error: " . curl_error($curl);
     } else {
         $responseArray = json_decode($response, true);
         if (isset($responseArray['payment_url'])) {
             $paymentUrl = $responseArray['payment_url'];
             header("Location: $paymentUrl");
             exit();
         } else {
             echo "Error: Payment URL not found in response.";
         }
     }
     curl_close($curl);
 }
 ?>