<html>
<head>
    <title>Payment</title>
    <script src="https://kit.fontawesome.com/524c5a650e.js" crossorigin="anonymous"></script>
</head>
<body>
    <style>
         html{
            user-select:none;
        }
        .display{
            display:flex;
            justify-content:center;
            align-items:center;
            width:100%;
            height:95vh;
        }
        .display .inner{
            max-width:400px;
            box-sizing:border-box;
            border:1px solid rgba(53, 52, 52, 0.557);
            border-radius:8px;
            padding:38px 24px;
            text-align:center;
        }
        .inner h1{
            margin:0px;
            color:rgb(206, 10, 10);
        }
        .inner .hello{
            margin:6px;
            padding:2px;
            font-size:16px;
        }
        .inner i{
            font-size:42px;
            color:rgb(18, 225, 7);
        }
        .inner h4{
            margin:0px;
            padding:4px;
        }
    </style>
    <div class="display">
        <div class="inner">
            <h1>Transaction Alert!</h1>
            <p class="hello">Your payment has been confirmed and the amount of placed order for postboost has been added to your current account.</p>
            <i class="fa-solid fa-circle-check"></i>
            <h4>Thank you for your time.</h4>
        </div>
    </div>
    </body>
    </html>