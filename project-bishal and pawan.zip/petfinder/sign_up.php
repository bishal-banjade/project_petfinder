<?php
include 'db.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/Exception.php';
require 'phpmailer/PHPMailer.php';
require 'phpmailer/SMTP.php';

if (isset($_POST['submit'])) {
    $name = trim($_POST['full-name']);
    $email = trim($_POST['email']);
    $address = trim($_POST['Address']);
    $password = $_POST['password'];
    $phone = trim($_POST['phone']);
    $confirm_password = $_POST['confirm-password'];
    $checksql = "SELECT * FROM users WHERE user_email='$email'";
    $checkresult = mysqli_query($conn, $checksql);

    if (mysqli_num_rows($checkresult) == 0) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $verification_code = rand(100000, 999999);
        session_start();

        $_SESSION['user_name'] = $name;
        $_SESSION['user_email'] = $email;
        $_SESSION['user_address'] = $address;
        $_SESSION['user_phone'] = $phone;
        $_SESSION['user_password'] = $hashed_password;
        $_SESSION['verification_code'] = $verification_code;

        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'finderpet275@gmail.com';
            $mail->Password = 'oydy pijk bjal hdci'; // Use environment variables for sensitive data
            $mail->SMTPSecure = 'ssl';
            $mail->Port = 465;

            $mail->setFrom('finderpet275@gmail.com', 'PetFinder');
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = 'Verify Your Email for PetFinder';
            $mail->Body = "<p>Your verification code for account registration is <b style='font-size:24px;margin-left:20px;'>$verification_code</b><br>Please do not share this message with anyone.<br><br>Thank you for your time.<br>petfinder.com<br>Web-Portal</p>";
            $mail->send();

            echo "<script>
                alert('Verification CODE has been sent to your registered Email ID ($email)');
                document.location.href = 'verify.php';
            </script>";
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        echo "<script> alert('Email already exists!');
        document.location.href = 'signup.php';
        </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./signup.css?v=<?php echo time(); ?>" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
    <title>Signup Page</title>
    <script>
        function signup() {
            var form = document.forms["signup-form"];
            var nameField = form["full-name"];
            var emailField = form["email"];
            var addressField = form["Address"];
            var passwordField = form["password"];
            var confirmPasswordField = form["confirm-password"];
            var phoneField = form["phone"];
            var termsField = form["terms"];

            // Reset styles
            nameField.style.border = "";
            emailField.style.border = "";
            addressField.style.border = "";
            phoneField.style.border = "";
            passwordField.style.border = "";
            confirmPasswordField.style.border = "";

            // Validate name
            if (nameField.value.trim() === "" || !/^[A-Za-z ]+$/.test(nameField.value)) {
                nameField.style.border = "5px solid red";
                nameField.placeholder = 'Invalid Name Format!';
                return false;
            }

            // Validate email for Gmail format
            if (!/^[a-z][a-zA-Z0-9._%+-]+@gmail\.com$/.test(emailField.value)) {
                emailField.style.border = "5px solid red";
                emailField.placeholder = 'Email must be a valid Gmail address!';
                return false;
            }

            // Validate address
            if (addressField.value.trim() === "") {
                addressField.style.border = "5px solid red";
                addressField.placeholder = 'Address cannot be empty!';
                return false;
            }

            // Validate phone
            if (!/^\d{10}$/.test(phoneField.value)) {
                phoneField.style.border = "5px solid red";
                phoneField.placeholder = 'Invalid Phone Number!';
                return false;
            }


            if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/.test(passwordField.value)) {
                passwordField.style.border = "5px solid red";
                passwordField.placeholder = 'Password must include at least 8 characters, one uppercase letter, one lowercase letter, one number, and one special character!';
                return false;
            }

            // Validate confirm password
            if (confirmPasswordField.value.trim() === "" || passwordField.value.trim() === "" || passwordField.value !== confirmPasswordField.value) {
                confirmPasswordField.style.border = "5px solid red";
                confirmPasswordField.placeholder = 'Passwords do not match!';
                return false;
            }

            // Validate terms
            if (!termsField.checked) {
                alert("You must agree to the Terms and Conditions.");
                return false;
            }

            return true;
        }

        // Function to toggle password visibility
        function togglePasswordVisibility(fieldId, iconId) {
            var passwordField = document.getElementById(fieldId);
            var icon = document.getElementById(iconId);
            if (passwordField.type === "password") {
                passwordField.type = "text";
                icon.classList.remove("fa-eye");
                icon.classList.add("fa-eye-slash");
            } else {
                passwordField.type = "password";
                icon.classList.remove("fa-eye-slash");
                icon.classList.add("fa-eye");
            }
        }
    </script>
</head>

<body>
    <form id="signup-form" method="post" autocomplete="off" action="./sign_up.php" onsubmit="return signup()">
        <div class="form-header">
            <img src="photo/logo.png" alt="Your Logo" class="logof" />
            <h1>Sign Up</h1>
        </div>
        <div class="form-group">
            <label for="full-name">Full Name</label>
            <input type="text" id="full-name" name="full-name" required />
        </div>
        <div class="form-group">
            <label for="email">Email Address</label>
            <input type="email" id="email" name="email" required />
        </div>
        <div class="form-group">
            <label for="address">Address</label>
            <input type="text" id="address" name="Address" required />
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <div style="position: relative;">
                <input type="password" id="password" name="password" required />
                <i class="fas fa-eye" id="togglePassword" style="cursor: pointer; position: absolute; right: 10px; top: 50%; transform: translateY(-50%);" onclick="togglePasswordVisibility('password', 'togglePassword')"></i>
            </div>
        </div>
        <div class="form-group">
            <label for="confirm-password">Confirm Password</label>
            <div style="position: relative;">
                <input type="password" id="confirm-password" name="confirm-password" required />
                <i class="fas fa-eye" id="toggleConfirmPassword" style="cursor: pointer; position: absolute; right: 10px; top: 50%; transform: translateY(-50%);" onclick="togglePasswordVisibility('confirm-password', 'toggleConfirmPassword')"></i>
            </div>
        </div>
        <div class="form-group">
            <label for="phone">Phone Number</label>
            <input type="tel" id="phone" placeholder="Phone Number" name="phone" maxlength="10" required />
        </div>
        <div class="form-group">
            <input type="checkbox" id="terms" name="terms" required />
            <label for="terms">I agree to the <a href="/terms">Terms and Conditions</a> and <a href="/privacy">Privacy Policy</a></label>
        </div>
        <div class="form-group">
            <button type="submit" name="submit">Submit</button>
        </div>
        <p>Already have an account? <a href="./login.php" class="loginx">Log in here</a>.</p>
    </form>
</body>

</html>