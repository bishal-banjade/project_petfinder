<?php
include('connect.php');
session_start();
$id = $_SESSION['users'];
if (empty($_SESSION['users'])) {
    header('Location:userdash.php');
}

if (isset($_GET['pet_id'])) {
    $id = $_GET['pet_id'];
    $sql = "DELETE FROM add_pets where pet_id='$id'";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        header("Location:userpost.php");
    }
}
