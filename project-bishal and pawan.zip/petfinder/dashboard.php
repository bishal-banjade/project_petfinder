<?php
include 'db.php';
include 'nav2.php';


$visitPage = 'dashboard.php';
$visitDate = date('Y-m-d');


$sql = "INSERT INTO traffic_logs (user_id,visit_date, page) VALUES ('$user_id','$visitDate', '$visitPage')";
$conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Pet Finder Dashboard</title>
    <link rel="stylesheet" href="./dashboard.css?v=<?php echo time(); ?>" />
    <style>
        .pet-buttons {
            display: flex;
            justify-content: space-between;
            margin-top: auto;
            padding: 8px;
        }

        .btn-details,
        .btn-adopt {
            padding: 8px 8px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 35%;
        }

        .btn-details {
            background-color: #007bff;
            color: white;
        }

        .btn-adopt {
            background-color: #ffc107;
            color: black;
        }
    </style>
</head>

<body>
    <?php include 'search.php'; ?>
    <?php include 'footer.php'; ?>
</body>

</html>