<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;600&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            user-select: none;
        }

        .outer {
            max-width: 60%;
            margin: 0 auto;
            padding: 20px;
            border-radius: 5px;
            background-color: #f9f9f9;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            margin: 12px 0;
            color: #333;
        }

        .box p {
            font-size: 16px;
            line-height: 1.6;
            color: #555;
        }

        ul {
            margin-left: 20px;
            list-style-type: disc;
        }

        @media (max-width: 768px) {
            .outer {
                padding: 10px;
            }

            .box p {
                font-size: 14px;
            }
        }
    </style>
</head>

<body>
    <div class="outer">
        <div class="box">
            <h2>Privacy Policy</h2>
            <p>Your privacy is important to us. This policy explains how we collect and use your personal information on our website, Pet Finder.</p>

            <h3>Information We Collect</h3>
            <ul>
                <li>Personal details (name, email).</li>
                <li>Usage data (how you use our site).</li>
            </ul>

            <h3>How We Use Your Information</h3>
            <ul>
                <li>To provide our services.</li>
                <li>To improve user experience.</li>
                <li>To communicate with you.</li>
            </ul>

            <h3>Data Protection</h3>
            <p>We take your privacy seriously and use security measures to protect your information.</p>

            <h3>Changes to This Policy</h3>
            <p>We may update this policy occasionally. We will notify you of any changes.</p>

            <h3>Contact Us</h3>
            <p>If you have questions about this policy, please contact us at [contact information].</p>
        </div>
    </div>
</body>

</html>