<?php
phpinfo();
?>
<!-- n -->