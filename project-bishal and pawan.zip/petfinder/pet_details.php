<?php
include 'db.php';
include 'nav2.php';



if (empty($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$id = $_SESSION['user_id'];
if (isset($_GET['id'])) {
    $pet_id = intval($_GET['id']);
    $pet_query = "
        SELECT 
            add_pets.* 
        FROM 
            add_pets 
        WHERE pet_id=?;    
    ";

    $stmt = $conn->prepare($pet_query);
    $stmt->bind_param('i', $pet_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $pet = $result->fetch_assoc();
    } else {
        echo "Pet not found.";
        exit();
    }
} else {
    echo "No pet ID provided.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo htmlspecialchars($pet['pet_name']); ?> - Pet Details</title>
    <link rel="stylesheet" href="./pet_details.css" />
    <style>
        .blur {
            filter: blur(4px);
            color: rgba(0, 0, 0, 0.5);
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="pet-header">
            <img src="<?php echo $pet["pet_photos"] ?>" alt="Pet Photo" class="pet-photo" />
            <h1 class="pet-name"><?php echo htmlspecialchars($pet['pet_name']); ?></h1>
        </div>

        <div class="details">
            <p><strong>Category:</strong> <?php echo htmlspecialchars($pet['pet_category']); ?></p>
            <p><strong>Age:</strong> <?php echo htmlspecialchars($pet['age']); ?> years</p>
            <p><strong>Breed:</strong> <?php echo htmlspecialchars($pet['pet_breed']); ?></p>
            <p><strong>Weight:</strong> <?php echo htmlspecialchars($pet['weight']); ?> kg</p>
            <p><strong>Health Status:</strong> <?php echo htmlspecialchars($pet['health_status']); ?></p>
            <p><strong>Description:</strong> <?php echo htmlspecialchars($pet['description']); ?></p>
            <p><strong>Price:</strong> <span class="price">RS<?php echo htmlspecialchars($pet['price']); ?></span></p>
        </div>

        <div class="owner-details" id="ownerDetails" style="display:none;">
            <h3>Owner Details</h3>
            <p><strong>Name:</strong> <?php echo htmlspecialchars($pet['owner_name']); ?></p>
            <p><strong>Email:</strong>
            <p class="blur"> <?php echo htmlspecialchars($pet['owner_email']); ?></p>
            </p>
            <p><strong>Phone no:</strong>
            <p class="blur"> <?php echo htmlspecialchars($pet['phone_no']); ?></p>
            </p>
            <p><strong>Address:</strong> <?php echo htmlspecialchars($pet['owner_address']); ?></p>
        </div>

        <div class="actions">
            <?php if ($id != $pet['owner_id']):
            ?>
                <button class="btn-adopt" onclick="adoptPet(<?php echo htmlspecialchars($pet['pet_id']); ?>)">Adopt me</button>
            <?php else: ?>
                <button class="btn-adopt" onclick="alert('You cannot adopt your own pet. Try adopting another pet.');">Adopt me</button>
            <?php endif; ?>
            <button onclick="showContactInfo()">Contact Owner</button>
        </div>
    </div>
    <?php include 'footer.php' ?>

    <script>
        function showContactInfo() {
            const ownerDetails = document.getElementById('ownerDetails');
            ownerDetails.style.display = ownerDetails.style.display === 'none' ? 'block' : 'none';
        }

        function adoptPet(petId) {
            <?php if (empty($_SESSION['user_id'])): ?>
                alert("Please login before adopting a pet.");
                window.location.href = 'login.php';
            <?php else: ?>
                window.location.href = 'adopt2.php?id=' + petId;
            <?php endif; ?>
        }
    </script>
</body>

</html>