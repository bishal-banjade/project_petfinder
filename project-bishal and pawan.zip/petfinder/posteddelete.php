<?php
include('db.php');
session_start();
if (empty($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}



if (isset($_GET['pet_id'])) {
    $petId = $_GET['pet_id'];
    $sql = "DELETE FROM add_pets where pet_id='$petId'";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        header("Location:userpost.php");
    }
}
