<?php
include('db2.php');
include('./adminnav.php');
require 'vendor/autoload.php';

use Cloudinary\Cloudinary;
use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->load();

$cloudinary = new Cloudinary(array(
    "cloud" => array(
        "cloud_name" => 'di6s2rhtn',
        "api_key" => '887923495746756',
        "api_secret" => '9Sh2np6pxJGbiKdA2H_4Kb-k3b4',
    )
));


$id = $_SESSION['user_id'];


$sql = "SELECT * FROM users WHERE user_id=?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt, $sql)) {
    die("SQL Error: " . mysqli_error($conn));
}
mysqli_stmt_bind_param($stmt, "s", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $dob = $row['dob'];
    $country = $row['country'];
    $street = $row['street'];
    $city = $row['city'];
    $martial = $row['martial'];
    $gender = $row['gender'];
    $prof = $row['profession'];
    $image = $row['imgurl'];
    $social = $row['social'];
} else {
    die("Error fetching data");
}

// Handle form submission
if (isset($_POST['submit'])) {
    $dob = $_POST['dob'];
    $country = $_POST['country'];
    $street = $_POST['street'];
    $city = $_POST['city'];
    $name = $_POST['uname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $mart = $_POST['mart'];
    $gender = $_POST['gender'];
    $prof = $_POST['profession'];
    $social = $_POST['social'];

    $PhotoUrls = $image; // Keep the existing image if no new one is uploaded
    if (isset($_FILES["image"]) && $_FILES["image"]["error"] == UPLOAD_ERR_OK) {
        $fileMimeType = mime_content_type($_FILES["image"]["tmp_name"]);
        if (strpos($fileMimeType, 'image') === 0) {
            try {
                $result = $cloudinary->uploadApi()->upload($_FILES["image"]["tmp_name"]);
                $PhotoUrls = $result['secure_url'];
            } catch (Exception $e) {
                die("Error uploading image: " . htmlspecialchars($e->getMessage()));
            }
        } else {
            die("Uploaded file is not an image.");
        }
    }

    // Update user information
    $query = "UPDATE users SET user_name=?, user_email=?, user_phone=?, gender=?, dob=?, martial=?, city=?, street=?, country=?, social=?, profession=?, imgurl=? WHERE user_id=?";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $query)) {
        die("SQL Error: " . mysqli_error($conn));
    }
    mysqli_stmt_bind_param($stmt, "ssssssssssssi", $name, $email, $phone, $gender, $dob, $mart, $city, $street, $country, $social, $prof, $PhotoUrls, $id);
    $result = mysqli_stmt_execute($stmt);

    if ($result) {
        header('Location:adminprofile.php'); // Redirect to admin profile page
        exit();
    } else {
        die(mysqli_error($conn));
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Profile Edit</title>
    <link rel="stylesheet" href="./profilepage.css">
    <script src="https://kit.fontawesome.com/524c5a650e.js" crossorigin="anonymous"></script>
</head>
<style>
    .main {
        margin-top: 120px;
    }

    .down {
        margin: 400px;
    }
</style>

<body>
    <div class="main">
        <div class="readme">
            <div class="des">
                <i class="fa-regular fa-circle-user"></i> ADMIN EDIT USER DETAILS
            </div>
        </div>
        <div class="text">
            <form action="" method="POST" enctype="multipart/form-data">
                <div class="down">
                    <div class="left">
                        <div class="camp">
                            <label class="input-file" for="input-file"><i class="fa-solid fa-camera"></i></label>
                        </div>
                        <div class="forimage">
                            <img src="<?php echo $image; ?>" id="profile-pic" alt="Profile Picture">
                            <input type="file" accept="image/*" id="input-file" name="image" style="display:none;">
                        </div>
                        <div class="name">
                            <h4><?php echo $row['user_name']; ?></h4>
                            <p class="rl">Editing User</p>
                        </div>
                        <div class="postdetails">
                            <div class="prof">
                                <input class="profes" type="text" value="<?php echo $prof; ?>" placeholder="Profession" name="profession">
                            </div>
                            <div class="social">
                                <input type="text" id="data" value="<?php echo $social; ?>" placeholder="Social Site" name="social">
                                <i id="uncopied" class="fa-regular fa-copy"></i>
                                <i id="copied" class="fa-solid fa-copy" style="display:none;"></i>
                            </div>
                        </div>
                    </div>
                    <div class="right">
                        <div class="top">
                            <p>Account Status</p>
                        </div>
                        <div class="below">
                            <div class="r1">
                                <label class="a">Username</label>
                                <input type="text" value="<?php echo $row['user_name']; ?>" name="uname">
                                <label class="a">Phone</label>
                                <input type="text" value="<?php echo $row['user_phone']; ?>" name="phone">
                                <label class="a">Email Address</label>
                                <input type="text" value="<?php echo $row['user_email']; ?>" name="email">
                                <label class="a">Date of Birth</label>
                                <input type="date" value="<?php echo $dob; ?>" name="dob">
                            </div>
                            <div class="r2">
                                <label class="a">Gender</label>
                                <input type="text" value="<?php echo $gender; ?>" name="gender">
                                <label class="a">Martial</label>
                                <input type="text" value="<?php echo $martial; ?>" name="mart">
                                <div class="addre">
                                    <div class="area">
                                        <label class="a">Street</label>
                                        <input type="text" value="<?php echo $street; ?>" name="street">
                                    </div>
                                    <div class="city">
                                        <label class="a">City</label>
                                        <input type="text" value="<?php echo $city; ?>" name="city">
                                    </div>
                                    <div class="count">
                                        <label class="a">Country</label>
                                        <input type="text" value="<?php echo $country; ?>" name="country">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="last">
                            <button class="cancel"><a href="adminprofile.php">Cancel</a></button>
                            <button type="submit" name="submit">Update</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <script>
        var data = document.getElementById('data');
        var copied = document.getElementById('copied');
        var uncopied = document.getElementById('uncopied');

        uncopied.onclick = function() {
            navigator.clipboard.writeText(data.value)
                .then(function() {
                    uncopied.style.display = 'none';
                    copied.style.display = 'block';
                    setTimeout(function() {
                        copied.style.display = 'none';
                        uncopied.style.display = 'block';
                    }, 2000);
                })
                .catch(function(error) {
                    console.error('Failed to copy text: ', error);
                });
        };

        let profilePic = document.getElementById("profile-pic");
        let inputFile = document.getElementById("input-file");

        inputFile.onchange = function() {
            profilePic.src = URL.createObjectURL(inputFile.files[0]);
        };
    </script>
    <style>
        .profes {
            outline: none;
            border: none;
            background: transparent;
            width: 100%;
            text-align: center;
        }

        .main .down .last .cancel {
            background: red;
        }

        .main .down .last .cancel a {
            text-decoration: none;
            color: #fff;
        }
    </style>
</body>

</html>