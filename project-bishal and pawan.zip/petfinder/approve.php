<?php

include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $pet_id = $_POST['pet_id'];


    $stmt = $conn->prepare("UPDATE add_pets SET upload = 1 WHERE pet_id = ?");
    $stmt->bind_param("i", $pet_id);


    if ($stmt->execute()) {
        echo "Pet approved successfully.";
    } else {
        echo "Error approving pet: " . $conn->error;
    }


    $stmt->close();
    $conn->close();


    header("Location: admin.php");
    exit();
}
