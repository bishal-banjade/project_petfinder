<?php
include('db.php');
include('nav2.php');

if (empty($_SESSION['user_id'])) {
    header('Location:login.php');
    exit();
}



$id = $_SESSION['user_id'];




//all post//
$query1 = "
    SELECT add_pets.* 
    FROM add_pets 
    left JOIN adopter ON add_pets.pet_id = adopter.pet_id 
    WHERE upload = 1 
    AND owner_id = '$id' 
    AND (dealout = 0 AND (adopter_id IS NULL OR adopter_id = 0)) 
    AND success = 0 AND payment=0
";
$resultPosts = mysqli_query($conn, $query1);
//deal in
$query2 = "SELECT * FROM add_pets INNER JOIN adopter where add_pets.pet_id = adopter.pet_id and upload=1 and dealout=1 and adopter_id='$id' and success=0";
$resultDealIn = mysqli_query($conn, $query2);
//deal out
$query3 = "
    SELECT add_pets.*, adopter.adopter_id 
    FROM add_pets 
    LEFT JOIN adopter ON add_pets.pet_id = adopter.pet_id 
    WHERE add_pets.upload = 1 
    AND add_pets.owner_id = '$id' 
    AND add_pets.success = 0 
    AND add_pets.dealout=1
    AND adopter.adopter_id IS NOT NULL
";
$resultDealOut = mysqli_query($conn, $query3);

$query5 = "SELECT * FROM add_pets INNER JOIN adopter where add_pets.pet_id = adopter.pet_id and  adopter_id='$id' and add_pets.dealout=1 and add_pets.payment=0 and add_pets.success=1";
$payDeals = mysqli_query($conn, $query5);

//closedeal
$query4 = "SELECT * FROM add_pets INNER JOIN adopter where add_pets.pet_id = adopter.pet_id and (owner_id='$id' or adopter_id='$id') and success=1 and payment=1";
$resultClosedDeals = mysqli_query($conn, $query4);
function displayPetPost($row, $sectionType)
{
    $petId = htmlspecialchars($row['pet_id']);


    $petName = htmlspecialchars($row['pet_name']);
    $petage = htmlspecialchars($row['age']);
    $petBreed = htmlspecialchars($row['pet_breed']);
    $petspecies = htmlspecialchars($row['pet_category']);
    $price = htmlspecialchars($row['price']);
    $petPhotos = htmlspecialchars($row['pet_photos']);
    $buttons = "";
    switch ($sectionType) {
        case 'all_posts':
            $buttons = "
                <button class='btn-details' onclick='update($petId)'>Update</button>
                <button class='btn-adopt' onclick='confirmation($petId)'>Delete</button>";
            break;
        case 'deal_in':
            $buttons = "
                <button class='btn-adopt' onclick='cancelDeal($petId)'>Cancel</button>
                  <button disable class='btn-adopt'>pending</button>";
            break;
        case 'deal_out':
            $buttons = "
                <button class='btn-adopt' onclick='acceptDeal($petId)'>Accept</button>
                <button class='btn-details' onclick='rejectDeal($petId)'>Reject</button>";
            break;
        case 'payment':
            $buttons = "
                <button class='btn-adopt' onclick='payDeal($petId,$price)' >payment</button>";

            break;
        case 'closed_deals':
            $buttons = "<p>Status: Accepted</p>";
            break;
    }


    echo '<section class="pet-cart">
     <div class="pet-cart1"> 
    <div class="pet-search">
    


                                <img src=' . $petPhotos . ' alt="Pet Photo" class="pet-photo" />
                                <div class="pet-item">
                                    <h3 class="pet-name">Name:' . $petName . '</h3>
                                    <p class="pet-breed">Species: ' . $petspecies . '</p>
                                    <p class="pet-breed">Breed: ' . $petBreed . '</p>
                                    <p class="pet-age">Age: ' . $petage . '</p>
                                    <strong>Price:<p class="pet-price"> RS ' . $price . '</p></strong>
                                    <div class="pet-buttons">
                                        ' . $buttons . '
                                    </div>
                                </div>
                            </div>
                            </div>
                            </section>
                            ';
}
?>


<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Manage Pets</title>
    <link rel="stylesheet" href="./userpost.css ?v=<?php echo time(); ?>">
    <script src="https://kit.fontawesome.com/524c5a650e.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="/resources/demos/style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
    <script>
        $(function() {
            $("#tabs").tabs();
        });
    </script>
    <script type="text/javascript">
        function confirmation(id) {

            if (confirm("Are you sure you want to delete this pet?")) {
                document.location.href = `posteddelete.php?pet_id=${id}`;
            }
        }

        function cancelDeal(id) {
            if (confirm("Are you sure you want to cancel this deal?")) {
                document.location.href = `cancel_deal.php?pet_id=${id}`;
            }
        }

        function acceptDeal(id) {
            if (confirm("Are you sure you want to accept this deal?")) {
                document.location.href = `accept_deal.php?pet_id=${id}`;
            }
        }

        function rejectDeal(id) {
            if (confirm("Are you sure you want to reject this deal?")) {
                document.location.href = `reject_deal.php?pet_id=${id}`;
            }
        }

        function payDeal(id, price) {
            if (confirm("Are you sure you want to make a payment on this deal?")) {
                document.location.href = `payment/payment.php?pet_id=${id}&pay=${price}`;
            }
        }

        function update(id) {
            if (confirm("Are you sure you want to update your pet_infromation")) {
                document.location.href = `update_pet.php?pet_id=${id}`;

            }
        }
    </script>
</head>

<body>
    <div class="box1">
        <div id="tabs">
            <ul>
                <li><a href="#all_posts">Total Post</a></li>
                <li><a href="#deal_in">Deal in</a></li>
                <li><a href="#deal_out">Deal out</a></li>
                <li><a href="#payment">payment</a></li>
                <li><a href="#closed_deals">Closed Deal</a></li>
            </ul>


            <div id="all_posts">
                <div class="postcards">
                    <?php
                    if ($resultPosts) {
                        while ($row = mysqli_fetch_assoc($resultPosts)) {
                            echo displayPetPost($row, 'all_posts');
                        }
                    } else {
                        echo "<p>No pets found.</p>";
                    }
                    ?>
                </div>
            </div>
            <div id="deal_in">
                <div class="postcards">
                    <?php
                    if ($resultDealIn) {
                        while ($row = mysqli_fetch_assoc($resultDealIn)) {
                            echo displayPetPost($row, 'deal_in');
                        }
                    } else {
                        echo "<p>No pending adoption requests.</p>";
                    }
                    ?>
                </div>
            </div>
            <div id="deal_out">
                <div class="postcards">
                    <?php
                    if ($resultDealOut) {
                        while ($row = mysqli_fetch_assoc($resultDealOut)) {
                            echo displayPetPost($row, 'deal_out');
                        }
                    } else {
                        echo "<p>No pending deals to adopt.</p>";
                    }
                    ?>
                </div>
            </div>
            <div id="payment">

                <div class="postcards">
                    <?php
                    if ($payDeals) {
                        while ($row = mysqli_fetch_assoc($payDeals)) {
                            echo displayPetPost($row, 'payment');
                        }
                    } else {
                        echo "<p>No pay deals.</p>";
                    }
                    ?>
                </div>
            </div>
            <div id="closed_deals">

                <div class="postcards">
                    <?php
                    if ($resultClosedDeals) {
                        while ($row = mysqli_fetch_assoc($resultClosedDeals)) {
                            echo displayPetPost($row, 'closed_deals');
                        }
                    } else {
                        echo "<p>No closed deals.</p>";
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</body>

</html>