<?php
include 'db2.php';

function fetchAssoc($result)
{
  return $result ? $result->fetch_assoc() : null;
}

$result = $conn->query("SELECT SUM(price) as total FROM add_pets WHERE payment = 1 AND success = 1");
$totalSales = fetchAssoc($result)['total'] ?? 0;

$result = $conn->query("SELECT COUNT(*) as total FROM users WHERE status = 'user'");
$totalUsers = fetchAssoc($result)['total'] ?? 0;

$result = $conn->query("SELECT COUNT(*) as total FROM add_pets WHERE upload = 0");
$newMessages = fetchAssoc($result)['total'] ?? 0;

$result = $conn->query("SELECT COUNT(*) as total FROM add_pets WHERE success = 1 AND payment = 1");
$successfulTransactions = fetchAssoc($result)['total'] ?? 0;

$currentYear = date('Y');

$salesDataCurrentYear = array_fill(1, 12, 0);
$salesDataPreviousYear = array_fill(1, 12, 0);

$result = $conn->query("SELECT SUM(price) as sales, MONTH(created_at) as month, YEAR(created_at) as year 
                         FROM add_pets 
                         WHERE payment = 1 AND success = 1 
                         AND YEAR(created_at) IN ($currentYear, " . ($currentYear - 1) . ") 
                         GROUP BY MONTH(created_at), YEAR(created_at)");

while ($row = fetchAssoc($result)) {
  $month = $row['month'];
  $year = $row['year'];
  if ($year == $currentYear) {
    $salesDataCurrentYear[$month] += $row['sales'] ?? 0;
  } else {
    $salesDataPreviousYear[$month] += $row['sales'] ?? 0;
  }
}

$monthLabels = [
  1 => 'January',
  2 => 'February',
  3 => 'March',
  4 => 'April',
  5 => 'May',
  6 => 'June',
  7 => 'July',
  8 => 'August',
  9 => 'September',
  10 => 'October',
  11 => 'November',
  12 => 'December',
];

$labelsForChart = [];
$salesDataForChart = [];
foreach ($monthLabels as $monthNumber => $monthName) {
  $labelsForChart[] = $monthName . " " . ($currentYear - 1);
  $labelsForChart[] = $monthName . " " . $currentYear;
  $salesDataForChart[] = $salesDataPreviousYear[$monthNumber];
  $salesDataForChart[] = $salesDataCurrentYear[$monthNumber];
}

$trafficData = [];
for ($i = 0; $i < 4; $i++) {
  $date = date('Y-m-d', strtotime("-$i week"));
  $result = $conn->query("SELECT COUNT(*) as count FROM traffic_logs WHERE visit_date = '$date'");
  $row = fetchAssoc($result);
  $trafficData[] = $row['count'] ?? 0;
}

$trafficData = array_reverse($trafficData);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
  <title>PetFinder Admin</title>
  <link rel="stylesheet" href="admin.css?v=<?php echo time(); ?>" />
  <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css" />
  <script src="https://kit.fontawesome.com/0cf1d61e41.js" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    .main-content {
      padding: 20px;
      margin-top: 30px;
    }

    .header {
      background: #ffffff;
      padding: 15px;
      border-radius: 5px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    }

    .dashboard-overview {
      background: #ffffff;
      border-radius: 8px;
      padding: 20px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      margin-top: 20px;
    }

    .metrics {
      display: flex;
      justify-content: space-between;
      margin-bottom: 20px;
    }

    .metric-card {
      background: #e9ecef;
      border-radius: 8px;
      padding: 20px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      flex: 1;
      margin: 0 10px;
      text-align: center;
      transition: background 0.3s;
    }

    .metric-card:hover {
      background: #d3d3d3;
    }

    .charts {
      display: flex;
      justify-content: space-between;
    }

    canvas {
      flex: 1;
      margin: 0 20px;
      max-width: 400px;
      max-height: 300px;
    }

    .header-menu .user .home-button span {
      margin-right: 0.5rem;
      font-size: 1.5rem;
    }

    @media (min-width: 768px) {
      canvas {
        max-width: 400px;
        max-height: 250px;
      }
    }

    @media (min-width: 1024px) {
      canvas {
        max-width: 500px;
        max-height: 300px;
      }
    }
  </style>
</head>

<body>
  <?php include 'adminnav.php' ?>

  <div class="dashboard-overview">
    <h2>Welcome Admin</h2>
    <div class="metrics">
      <div class="metric-card">
        <h3>Total Users</h3>
        <p id="total-users"><?php echo $totalUsers; ?></p>
      </div>
      <div class="metric-card">
        <h3>Total Sales</h3>
        <p id="total-sales">Rs<?php echo number_format($totalSales, 2); ?></p>
      </div>
      <div class="metric-card">
        <h3>New Messages</h3>
        <p id="new-messages"><?php echo $newMessages; ?></p>
      </div>
      <div class="metric-card">
        <h3>Successful Transactions</h3>
        <p id="successful-transactions"><?php echo $successfulTransactions; ?></p>
      </div>
    </div>
    <div class="charts">
      <canvas id="salesChart" width="300" height="200"></canvas>
      <canvas id="trafficChart" width="300" height="200"></canvas>
    </div>
  </div>

  <script>
    const ctxSales = document.getElementById("salesChart").getContext("2d");
    const salesChart = new Chart(ctxSales, {
      type: "line",
      data: {
        labels: <?php echo json_encode($labelsForChart); ?>, // Updated month labels with years
        datasets: [{
          label: "Sales",
          data: <?php echo json_encode($salesDataForChart); ?>, // Updated sales data
          borderColor: "rgba(75, 192, 192, 1)",
          borderWidth: 2,
          fill: false,
        }],
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true,
          },
        },
      },
    });

    // Initialize Traffic Chart
    const ctxTraffic = document.getElementById("trafficChart").getContext("2d");
    const trafficChart = new Chart(ctxTraffic, {
      type: "bar",
      data: {
        labels: ["Week 1", "Week 2", "Week 3", "Week 4"],
        datasets: [{
          label: "Website Traffic",
          data: <?php echo json_encode($trafficData); ?>,
          backgroundColor: "rgba(153, 102, 255, 0.5)",
          borderColor: "rgba(153, 102, 255, 1)",
          borderWidth: 1,
        }],
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true,
          },
        },
      },
    });
  </script>
</body>

</html>