<?php

include 'db.php';
require 'vendor/autoload.php';

// Load environment variables
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

use Cloudinary\Cloudinary;
use Cloudinary\Uploader;

// Load Cloudinary configuration
$cloudinary = new Cloudinary(array(
    "cloud" => array(
        "cloud_name" => getenv('petfinder'),
        "api_key" => getenv('887923495746756'),
        "api_secret" => getenv('9Sh2np6pxJGbiKdA2H_4Kb-k3b4')
    )
));
echo "Cloud Name: " . getenv('CLOUDINARY_CLOUD_NAME') . "<br>";
echo "API Key: " . getenv('CLOUDINARY_API_KEY') . "<br>";
echo "API Secret: " . getenv('CLOUDINARY_API_SECRET') . "<br>";

// Your existing code continues here...