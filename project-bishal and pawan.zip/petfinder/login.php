<?php
session_start();
include 'db.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $phone = trim($_POST['email']);
    $password = $_POST['password'];

    // Prepare statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM users WHERE user_email = ?");
    if (!$stmt) {
        die("Prepare failed: " . htmlspecialchars($conn->error));
    }

    $stmt->bind_param("s", $phone);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Verify password
        if (password_verify($password, $user['user_passwords'])) {
            // Set session variables
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['user_name'];
            $_SESSION['useremail'] = $user['user_email'];
            $_SESSION['useraddress'] = $user['user_address'];
            $_SESSION['phoneno'] = $user['user_phone'];
            $_SESSION['role'] = $user['status'];

            // Redirect based on user role
            if ($user['status'] === 'user') {
                header("Location: dashboard.php");
            } else {
                header("Location: admin.php");
            }
            exit();
        } else {
            $error_message = 'Invalid password.';
        }
    } else {
        $error_message = 'No user found with that email address.';
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login</title>
    <link rel="stylesheet" href="./login.css?v=<?php echo time(); ?>" />
</head>

<body>
    <?php include 'nav.php'; ?>
    <form id="login-form" method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" autocomplete="off">
        <div class="form-header">
            <img src="photo/logo.png" alt="Your Logo" class="logof" />
            <h1>Login</h1>
        </div>
        <div class="form">
            <div class="login">
                <label for="phone">Email</label>
                <input type="email" id="phone" name="email" placeholder="Enter your email" required />
            </div>
            <div class="login">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="Enter your password" required />
            </div>
            <div class="login" id="forgot-password">
                <a href="#" id="forgot-link">Forgot password?</a>
            </div>
            <div class="login">
                <button type="submit" name="submit">Login</button>
            </div>
            <div class="login">
                <label>Don't have an account?</label>
                <a href="./sign_up.php">Sign Up</a>
            </div>
        </div>
    </form>

    <?php if (!empty($error_message)): ?>
        <script>
            alert("<?php echo $error_message; ?>");
        </script>
    <?php endif; ?>
</body>

</html>