<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pet_finder";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
session_start();
$user_id = $_SESSION['user_id'];
if (empty($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location:login.php');
}
?>
<!-- bishal -->