<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Document</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Cambria, Cochin, Georgia, Times, "Times New Roman", serif;
        }

        :root {
            --color-black: #141d28de;
            --color-primary: #0073ff;
            --color-white: #e9e9e9;
            --color-light-gray: #cdcdcd;
        }

        .menu-container {
            max-width: 100%;
            position: sticky;
            top: 0;
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            background-color: rgba(20, 29, 40, 1);
            padding: 20px;
            z-index: 1000;
            -webkit-user-select: none;
            user-select: none;
            box-sizing: border-box;
            transition: background-color 0.1s ease;
            width: 100%;
        }

        .menu-logo {
            line-height: 0;
            margin: 0 20px;
        }

        .menu-logo img {
            max-height: 80px;
            max-width: 100px;
            flex-shrink: 0;
        }

        .menu-container a {
            text-decoration: none;
            transition: color 0.1s ease;
        }

        .link:hover,
        .logobutton:hover {
            color: var(--color-white);
            background-color: var(--color-black);
        }

        .menu-container input {
            display: block;
            width: 35px;
            height: 25px;
            margin: 0;
            position: absolute;
            cursor: pointer;
            opacity: 0;
            z-index: 2;
            -webkit-touch-callout: none;
        }

        .logobutton,
        .link {
            border: none;
            padding: 8px;
            margin: 0;
            border-radius: 9px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
            transition: background-color 0.1s ease, color 0.1s ease;
            display: flex;
            align-items: center;
        }

        .menu-container span {
            display: block;
            width: 33px;
            height: 4px;
            margin-bottom: 5px;
            position: relative;
            background: var(--color-light-gray);
            border-radius: 3px;
            z-index: 1;
            transform-origin: 4px 0px;
            transition: transform 0.5s cubic-bezier(0.77, 0.2, 0.05, 1.0),
                background 0.5s cubic-bezier(0.77, 0.2, 0.05, 1.0),
                opacity 0.55s ease;
        }

        .menu ul {
            list-style: none;
        }

        .menu li {
            padding: 10px 15px;
            font-size: 22px;
            display: flex;
            align-items: center;
        }

        .menu li a {
            display: flex;
            align-items: center;
            color: var(--color-white);
            transition: color 0.1s ease;
        }

        .menu li i {
            font-size: 20px;
            color: var(--color-white);
            transition: color 0.1s ease;
            margin-right: 5px;
        }

        .menu li:hover {
            background-color: rgba(255, 255, 255, 0.2);
            border-radius: 5px;
            transform: scale(1.05);
        }

        .menu li:hover i {
            color: var(--color-primary);
        }

        @media only screen and (max-width: 767px) {
            .menu-container {
                flex-direction: column;
                align-items: flex-end;
            }

            .menu-logo {
                position: absolute;
                left: 0;
                top: 50%;
                transform: translateY(-50%);
            }

            .menu-logo img {
                max-height: 30px;
            }

            .menu {
                position: absolute;
                box-sizing: border-box;
                width: 300px;
                right: -300px;
                top: 0;
                margin: -20px;
                padding: 75px 50px 50px;
                background: var(--color-light-gray);
                -webkit-font-smoothing: antialiased;
                transform-origin: 0% 0%;
                transform: translateX(0%);
                transition: transform 0.5s cubic-bezier(0.77, 0.2, 0.05, 1.0);
            }

            .menu-container input:checked~.menu {
                transform: translateX(-100%);
            }

            .menu li {
                font-size: 18px;
            }
        }

        @media only screen and (min-width: 768px) {
            .menu-container {
                width: 100%;
            }

            .menu-container a {
                color: var(--color-light-gray);
            }

            .menu-container input {
                display: none;
            }

            .menu-container span {
                display: none;
            }

            .menu {
                position: relative;
                width: 100%;
                display: flex;
                justify-content: space-between;
            }

            .menu ul {
                display: flex;
                padding: 0;
            }

            .menu li {
                padding: 0 20px;
                font-size: 22px;
            }

            .menu li:hover {
                background-color: rgba(255, 255, 255, 0.1);
                border-radius: 5px;
            }
        }
    </style>
</head>

<body>

    <nav class="menu-container">
        <input type="checkbox" aria-label="Toggle menu" />
        <span></span>
        <span></span>
        <span></span>
        <a href="#" class="menu-logo">
            <img src="photo/logo.png" alt="My Awesome Website" />
        </a>
        <div class="menu">
            <ul>
                <li>
                    <a href="./Home.php" class="link">
                        <i class="fas fa-home"></i> Home
                    </a>
                </li>
                <li>
                    <a href="./about.php" class="link">
                        <i class="fas fa-info-circle"></i> About us
                    </a>
                </li>
            </ul>
            <ul>
                <li>
                    <a href="./sign_up.php" class="logobutton">
                        <i class="fas fa-user-plus"></i> Sign-up
                    </a>
                </li>
                <li>
                    <a href="./login.php" class="logobutton">
                        <i class="fas fa-sign-in-alt"></i> Login
                    </a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="content"></div>

</body>

</html>