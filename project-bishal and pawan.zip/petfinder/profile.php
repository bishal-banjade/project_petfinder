<?php

include('db.php');
include('./nav2.php');

$id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$email = $_SESSION['useremail'];
$phone = $_SESSION['phoneno'];

$sql = "SELECT * FROM users WHERE user_id=?";
$stmt = mysqli_stmt_init($conn);
if (!mysqli_stmt_prepare($stmt, $sql)) {
    echo "Error" . mysqli_error($conn);
}
mysqli_stmt_bind_param($stmt, "s", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $dob = $row['dob'];
    $country = $row['country'];
    $street = $row['street'];
    $city = $row['city'];
    $martial = $row['martial'];
    $gender = $row['gender'];
    $prof = $row['profession'];
    $image = $row['imgurl'];
    $social = $row['social'];
} else {
    die("Error fetching data");
}
?>

<?php

$query1 = "SELECT COUNT(*) AS pet_count FROM add_pets LEFT JOIN adopter ON add_pets.pet_id = adopter.pet_id WHERE upload = 1 AND owner_id = '$id' AND (dealout = 0 AND (adopter_id IS NULL OR adopter_id = 0)) AND success = 0 AND payment = 0";
$resultPosts = mysqli_query($conn, $query1);
$row1 = mysqli_fetch_array($resultPosts)['pet_count'];

$query2 = "SELECT COUNT(*) AS deal_in_count FROM add_pets INNER JOIN adopter ON add_pets.pet_id = adopter.pet_id WHERE upload = 1 AND dealout = 1 AND adopter_id = '$id' AND success = 0";
$resultDealIn = mysqli_query($conn, $query2);
$row2 = mysqli_fetch_array($resultDealIn)['deal_in_count'];

$query3 = "SELECT COUNT(*) AS deal_out_count FROM add_pets LEFT JOIN adopter ON add_pets.pet_id = adopter.pet_id WHERE add_pets.upload = 1 AND add_pets.owner_id = '$id' AND add_pets.success = 0 AND add_pets.dealout = 1 AND adopter.adopter_id IS NOT NULL";
$resultDealOut = mysqli_query($conn, $query3);
$row3 = mysqli_fetch_array($resultDealOut)['deal_out_count'];

$query4 = "SELECT COUNT(*) AS closed_deal_count FROM add_pets INNER JOIN adopter ON add_pets.pet_id = adopter.pet_id WHERE (owner_id = '$id' OR adopter_id = '$id') AND success = 1 AND payment = 1";
$resultClosedDeals = mysqli_query($conn, $query4);
$row4 = mysqli_fetch_array($resultClosedDeals)['closed_deal_count'];

$query5 = "SELECT COUNT(*) AS payment_deal_count FROM add_pets INNER JOIN adopter ON add_pets.pet_id = adopter.pet_id WHERE adopter_id = '$id' AND add_pets.dealout = 1 AND add_pets.payment = 0 AND add_pets.success = 1";
$payDeals = mysqli_query($conn, $query5);
$countPayDeals = mysqli_fetch_array($payDeals)['payment_deal_count'];

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="profilepage.css">
    <script src="https://kit.fontawesome.com/524c5a650e.js" crossorigin="anonymous"></script>
    <script type="text/javascript">
        function update() {
            if (onclick = true) {
                document.location.href = `profileedit.php`;
                return true;
            }
        }
    </script>
</head>

<body>
    <div class="main">
        <div class="readme">
            <div class="des">
                <i class="fa-regular fa-circle-user"></i> USER DETAILS
            </div>
        </div>
        <div class="text">
            <div class="cover">
                <!-- cover -->
            </div>
            <div class="down">
                <div class="left">
                    <div class="camp">
                        <label class="input-file" for="input-file"><i class="fa-solid fa-camera"></i></label>
                    </div>
                    <div class="forimage">
                        <img src="<?php echo $image; ?>">
                    </div>
                    <div class="name">
                        <h4><?php echo $username; ?></h4>
                        <p class="rl">User</p>
                    </div>
                    <div class="postdetails">
                        <ul>
                            <li>
                                <p>Total Post</p><span class="blue"><?php echo $row1; ?></span>
                            </li>
                            <li>
                                <p>Incoming Deal</p><span class="yellu"><?php echo $row2; ?></span>
                            </li>
                            <li>
                                <p>Outgoing Deal</p><span class="red"><?php echo $row3; ?></span>
                            </li>
                            <li>
                                <p>Successful Deal</p><span class="greun"><?php echo $row4; ?></span>
                            </li>
                        </ul>
                        <div class="prof">
                            <p>Profession:</p><span><?php echo $prof; ?></span>
                        </div>
                        <div class="social">
                            <input type="box" disabled id="data" value="<?php echo $social; ?>"><i id="uncopied"
                                class="fa-regular fa-copy"></i><i id="copied" class="fa-solid fa-copy"></i>
                        </div>
                    </div>
                </div>
                <div class="right">
                    <div class="top">
                        <p>Account Status</p>
                    </div>
                    <div class="below">
                        <div class="r1">
                            <label class="a">Username</label>
                            <input disabled type="text" value="<?php echo $username; ?>">
                            <label class="a">Phone</label>
                            <input disabled type="text" value="<?php echo $phone; ?>">
                            <label class="a">Email Address</label>
                            <input disabled type="text" value="<?php echo $email; ?>">
                            <label class="a">Date of Birth</label>
                            <input disabled type="text" value="<?php echo $dob; ?>">
                        </div>
                        <div class="r2">
                            <label class="a">Gender</label>
                            <input disabled type="text" value="<?php echo $gender; ?>">
                            <label class="a">Martial</label>
                            <input disabled type="text" value="<?php echo $martial; ?>">
                            <div class="addre">
                                <div class="area">
                                    <label class="a">Street</label>
                                    <input disabled type="text" value="<?php echo $street; ?>">
                                </div>
                                <div class="city">
                                    <label class="a">City</label>
                                    <input disabled type="text" value="<?php echo $city; ?>">
                                </div>
                                <div class="count">
                                    <label class="a">Country</label>
                                    <input disabled type="text" value="<?php echo $country; ?>">
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="last">
                        <button href='javascript:void()' onclick='update()'>Edit Profile</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        var data = document.getElementById('data');
        var copied = document.getElementById('copied');
        var uncopied = document.getElementById('uncopied');

        uncopied.onclick = function() {
            navigator.clipboard.writeText(data.value)
                .then(function() {
                    uncopied.style.display = 'block';
                    setTimeout(function() {
                        copied.style.display = 'block';
                        uncopied.style.display = 'none';
                    }, 2);
                })
                .catch(function(error) {
                    console.error('Failed to copy text: ', error);
                });
        };
    </script>
</body>

</html>