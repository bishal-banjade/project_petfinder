<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

session_start();
$verification_code = rand(100000, 999999);
$_SESSION['verification_code'] = $verification_code;

$email = $_POST['email'];

try {
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;

    $mail->Username = 'finderpet275@gmail.com';
    $mail->Password = 'oydy pijk bjal hdci';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;

    $mail->setFrom('finderpet275@gmail.com', 'PetFinder');
    $mail->addAddress($email);

    $mail->isHTML(true);
    $mail->Subject = 'Verify Your Email for PetFinder';
    $mail->Body = "<p>Your verification code for account registration is <b style='font-size:24px;margin-left:20px;'><br>$verification_code</b><br>Please do not share this message with anyone<br><br>Thank you for your time<br>petfinder.com<br>Web-Portal</p>";

    if ($mail->send()) {
        echo "<script>alert('Verification code has been sent to your email.'); window.location.href='otp.php';</script>";
    } else {
        echo "<script>alert('Email could not be sent. Please try again later.');</script>";
    }
} catch (Exception $e) {
    echo "<script>alert('Message could not be sent. Mailer Error: {$mail->ErrorInfo}');</script>";
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forget Password</title>
    <link rel="stylesheet" href="forget.css">
</head>

<body>
    <div class="box">
        <form action="" method="POST" autocomplete="off" autosuggestion="off">
            <img src="rantel.png" alt="logo">
            <div class="top">
                <p class="hs">pet<span>finder</span><span class="nep">.com</span></p>
                <p class="ar">Account recovery</p>
            </div>
            <div class="msg">
                <p class="foremail">Please enter your username and email that you have registered in Web-Portal</p>
            </div>
            <div class="ib">
                <input type="text" name="name" placeholder="Enter your name" required>
                <input type="text" name="email" placeholder="Enter your email" required>
            </div>
            <div class="sub">
                <p class="last">Please click button on the right to get your OTP</p>
                <button type="submit" value="submit" name="send">Get OTP</button>
            </div>
        </form>
    </div>
</body>

</html>