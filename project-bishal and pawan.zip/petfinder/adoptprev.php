<?php
include 'db.php';
require 'vendor/autoload.php';
include './nav2.php';

use Cloudinary\Cloudinary;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->load();

if (!isset($user_id)) {
    die("You must be logged in to view this page.");
}


$stmt = $conn->prepare("SELECT * FROM adopter WHERE adopter_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $adopter = $result->fetch_assoc();
} else {
    die("No adoption records found.");
}


if (isset($_POST['update'])) {

    $adopterName = trim($_POST['full_name']);
    $adopterEmail = filter_var(trim($_POST['contact_email']), FILTER_VALIDATE_EMAIL);
    $adopterContact = trim($_POST['phone_number']);
    $adopterLocation = trim($_POST['address']);
    $adoptReason = trim($_POST['adoption_reason']);
    $city = trim($_POST['city']);
    $state = trim($_POST['state']);
    $country = trim($_POST['country']);
    $ownPets = trim($_POST['own_pets']);
    $vetName = trim($_POST['vet_name']);
    $homeStatus = $_POST['home_status'];
    $yard = $_POST['yard'];
    $children = trim($_POST['children']);
    $hoursAlone = intval($_POST['hours_alone']);
    $animalCrime = isset($_POST['animal_crime']) ? trim($_POST['animal_crime']) : '';


    if (empty($adopterName) || !$adopterEmail || empty($adopterContact) || empty($adopterLocation) || empty($adoptReason)) {
        die("All fields are required.");
    }


    $updateStmt = $conn->prepare("UPDATE adopter SET 
        adopter_name = ?, 
        adopter_email = ?, 
        adopter_phone = ?, 
        Address = ?, 
        city = ?, 
        state = ?, 
        country = ?, 
        own_pets = ?, 
        vet_name = ?, 
        home_status = ?, 
        yard = ?, 
        children = ?, 
        hours_alone = ?, 
        animal_crime = ? 
        WHERE adopter_id = ?");

    $updateStmt->bind_param(
        "ssssssssssssssi",
        $adopterName,
        $adopterEmail,
        $adopterContact,
        $adopterLocation,
        $city,
        $state,
        $country,
        $ownPets,
        $vetName,
        $homeStatus,
        $yard,
        $children,
        $hoursAlone,
        $animalCrime,
        $user_id
    );

    if ($updateStmt->execute()) {
        echo "<script>alert('Your information has been updated successfully.'); window.location.href = 'adoptsec.php';</script>";
    } else {
        die("Error updating information: " . htmlspecialchars($updateStmt->error));
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Adoption Information</title>
    <link rel="stylesheet" href="./adopt.css">
</head>

<body>
    <section>
        <div class="adoptcontainer">
            <form method="post" class="form-adopted">
                <h2>Update Adoption Information</h2>

                <label for="full_name">Full Name:<span style="color: red;">*</span></label>
                <input type="text" id="full_name" name="full_name" value="<?php echo htmlspecialchars($adopter['adopter_name']); ?>" required />

                <label for="contact_email">Email:<span style="color: red;">*</span></label>
                <input type="email" id="contact_email" name="contact_email" value="<?php echo htmlspecialchars($adopter['adopter_email']); ?>" required />

                <label for="phone_number">Phone Number:<span style="color: red;">*</span></label>
                <input type="text" id="phone_number" name="phone_number" value="<?php echo htmlspecialchars($adopter['adopter_phone']); ?>" required />

                <label for="address">Address:<span style="color: red;">*</span></label>
                <input type="text" id="address" name="address" value="<?php echo htmlspecialchars($adopter['Address']); ?>" required />

                <label for="city">City:<span style="color: red;">*</span></label>
                <input type="text" id="city" name="city" value="<?php echo htmlspecialchars($adopter['city']); ?>" required />

                <label for="state">State:<span style="color: red;">*</span></label>
                <input type="text" id="state" name="state" value="<?php echo htmlspecialchars($adopter['state']); ?>" required />

                <label for="country">Country:<span style="color: red;">*</span></label>
                <select id="country" name="country" required>
                    <option value="">Please Select</option>
                    <option value="Nepal" <?php echo ($adopter['country'] == 'Nepal' ? 'selected' : ''); ?>>Nepal</option>
                    <option value="USA" <?php echo ($adopter['country'] == 'USA' ? 'selected' : ''); ?>>United States</option>
                    <option value="Canada" <?php echo ($adopter['country'] == 'Canada' ? 'selected' : ''); ?>>Canada</option>
                </select>

                <label>Do you own any pets?<span style="color: red;">*</span></label>
                <div class="inline-options">
                    <input type="radio" id="pets_yes" name="own_pets" value="Yes" <?php echo ($adopter['own_pets'] == 'Yes' ? 'checked' : ''); ?> required />
                    <label for="pets_yes">Yes</label>
                    <input type="radio" id="pets_no" name="own_pets" value="No" <?php echo ($adopter['own_pets'] == 'No' ? 'checked' : ''); ?> required />
                    <label for="pets_no">No</label>
                </div>

                <div id="vetNameContainer" style="display: <?php echo ($adopter['own_pets'] == 'Yes' ? 'block' : 'none'); ?>;">
                    <label for="vet_name">Veterinarian's Name </label>
                    <input type="text" id="vet_name" name="vet_name" value="<?php echo htmlspecialchars($adopter['vet_name']); ?>" />
                </div>

                <label>Do you own your home?<span style="color: red;">*</span></label>
                <div class="inline-options">
                    <input type="radio" id="home_yes" name="home_status" value="Yes" <?php echo ($adopter['home_status'] == 'Yes' ? 'checked' : ''); ?> required />
                    <label for="home_yes">Yes</label>
                    <input type="radio" id="home_no" name="home_status" value="No" <?php echo ($adopter['home_status'] == 'No' ? 'checked' : ''); ?> required />
                    <label for="home_no">No</label>
                </div>

                <label for="children">Are there children in the home?<span style="color: red;">*</span></label>
                <input type="text" id="children" name="children" value="<?php echo htmlspecialchars($adopter['children']); ?>" required />

                <label for="hours_alone">How many hours per day would the pet be alone?<span style="color: red;">*</span></label>
                <input type="text" id="hours_alone" name="hours_alone" value="<?php echo htmlspecialchars($adopter['hours_alone']); ?>" required />

                <label for="adoption_reason">Reason for Adoption:<span style="color: red;">*</span></label>
                <textarea id="adoption_reason" name="adoption_reason" required><?php echo htmlspecialchars($adopter['Adopter_reason']); ?></textarea>

                <label for="animal_crime">Have you ever been convicted of an animal-related crime?<span style="color: red;">*</span></label>
                <div class="inline-options">
                    <input type="radio" id="yes" name="animal_crime" value="Yes" <?php echo ($adopter['animal_crime'] == 'Yes' ? 'checked' : ''); ?> required />
                    <label for="yes">Yes</label>
                    <input type="radio" id="no" name="animal_crime" value="No" <?php echo ($adopter['animal_crime'] == 'No' ? 'checked' : ''); ?> required />
                    <label for="no">No</label>
                </div>

                <div class="button-container">
                    <button type="button" class="cancel" onclick="window.location.href='adopt.php';">Cancel</button>
                    <button class="samebutton" type="submit" name="update">Update Information</button>
                </div>
            </form>
        </div>
    </section>
    <?php include './footer.php'; ?>
    <script>
        const ownPetsRadios = document.querySelectorAll('input[name="own_pets"]');
        ownPetsRadios.forEach(radio => {
            radio.addEventListener('change', function() {
                const vetNameContainer = document.getElementById('vetNameContainer');
                vetNameContainer.style.display = this.value === 'Yes' ? 'block' : 'none';
            });
        });
    </script>
</body>

</html>