<?php
include 'db.php';

require 'vendor/autoload.php';

use Cloudinary\Cloudinary;

use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->load();

$cloudinary = new Cloudinary(array(
    "cloud" => array(
        "cloud_name" => 'di6s2rhtn',
        "api_key" => '887923495746756',
        "api_secret" => '9Sh2np6pxJGbiKdA2H_4Kb-k3b4',
    )
));

session_start();
if (empty($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
$user_id = $_SESSION['user_id'];
$username =   $_SESSION['username'];
$email = $_SESSION['useremail'];
$address = $_SESSION['useraddress'];
$phone = $_SESSION['phoneno'];


if (isset($_GET['pet_id'])) {
    $petId = $_GET['pet_id'];
    $sqli = "SELECT * FROM add_pets WHERE pet_id = ?";
    $stmt = $conn->prepare($sqli);
    $stmt->bind_param("i", $petId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $petname = $row['pet_name'];
        $pet_category = $row['pet_category'];
        $age = $row['age'];
        $petDescription = $row['description'];
        $reason = $row['Reasontosale'];
        $health = $row['health_status'];
        $price = $row['price'];
        $breed = $row['pet_breed'];
        $weight = $row['weight'];
        $petPhoto = $row['pet_photos'];
    } else {
        echo "No pet found with that ID.";
        exit;
    }
} else {
    echo "Pet ID not specified.";
    exit;
}
if (isset($_POST['submit'])) {

    $petName = trim($_POST['pet_name']);
    $petCategory = trim($_POST['pet_category']);
    $petBreed = trim($_POST['breed']);
    $petSpayed = trim($_POST['spayed']);
    $healthStatus = trim($_POST['health_status']);
    $petDescription = trim($_POST['description']);
    $reason = trim($_POST['reason']);



    $petAge = filter_var(trim($_POST['age']), FILTER_VALIDATE_FLOAT);
    $petWeight = filter_var(trim($_POST['weight']), FILTER_VALIDATE_FLOAT);
    $petPrice = filter_var(trim($_POST['price']), FILTER_VALIDATE_FLOAT);

    $petPhotoUrls = null;
    if (isset($_FILES["pet_photos"]) && $_FILES["pet_photos"]["error"] == UPLOAD_ERR_OK) {
        $fileMimeType = mime_content_type($_FILES["pet_photos"]["tmp_name"]);
        if (strpos($fileMimeType, 'image') === 0) {
            try {
                $result = $cloudinary->uploadApi()->upload($_FILES["pet_photos"]["tmp_name"]);
                $petPhotoUrls = $result['secure_url'];
            } catch (Exception $e) {
                die("Error uploading image: " . htmlspecialchars($e->getMessage()));
            }
        } else {
            die("Uploaded file is not an image.");
        }
    } else {
        die("No file uploaded or there was an upload error.");
    }

    $sqli = "INSERT INTO update_pet (pet_id, owner_id, pet_name, pet_category, age, pet_breed, weight, spayed, health_status, description, Reasontosale, price, pet_photos, approved) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sqli);
    $stmt->bind_param("iissdsssssdss", $petId, $user_id, $petName, $petCategory, $petAge, $petBreed, $petWeight, $spayedStatus, $healthStatus, $petDescription, $reasonForSale, $petPrice, $petPhotoUrls, $approvedStatus);

    if ($stmt->execute()) {

        echo '<script> alert("Details has been submitted. Please wait for the admin approval to see the changes in your post");
        document.location.href = "userpost.php";
        </script>';
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Pet for Sale</title>
    <link rel="stylesheet" href="./addpet.css ?v=>?php echo time();?>">
</head>

<body>

    <div class=" container">

        <h2>Please Complete the Form Accurately</h2>
        <form id="petForm" action="addpet.php" method="POST" enctype="multipart/form-data">
            <h3>Seller Information</h3>
            <label for="seller_name">Full Name:</label>
            <input disabled type="text" id="seller_name" name="seller_name" value="<?php echo $username; ?> ">

            <label for="email">Email Address:</label>
            <input disabled type="email" id="email" name="email" value="<?php echo $email; ?> ">

            <label for="phone">Phone Number:</label>
            <input disabled type="text" id="phone" name="phone" value="<?php echo $phone; ?> ">

            <label for="location">Location:</label>
            <input disabled type="text" id="location" name="location" value="<?php echo $address; ?> ">

            <h3>Pet Information</h3>
            <label for="pet_category">Pet Category:</label>
            <select id="pet_category" name="pet_category" required>
                <option value="">Select Category</option>
                <option value="dog" <?php if ($pet_category == 'dog') echo 'selected'; ?>>Dog</option>
                <option value="cat" <?php if ($pet_category == 'cat') echo 'selected'; ?>>Cat</option>
                <option value="bird" <?php if ($pet_category == 'bird') echo 'selected'; ?>>Bird</option>
                <option value="Rabbit" <?php if ($pet_category == 'Rabbit') echo 'selected'; ?>>Rabbit</option>
                <option value="Fish" <?php if ($pet_category == 'Fish') echo 'selected'; ?>>Fish</option>
                <option value="Tortoise" <?php if ($pet_category == 'Tortoise') echo 'selected'; ?>>Tortoise</option>
                <option value="mammal" <?php if ($pet_category == 'mammal') echo 'selected'; ?>>Mammal</option>
            </select>

            <label for="pet_name">Pet Name:</label>
            <input type="text" id="pet_name" name="pet_name" value="<?php echo $petname; ?>">

            <label for="breed">Breed:</label>
            <input type="text" id="breed" name="breed" value="<?php echo htmlspecialchars($breed); ?>" required>

            <label for="age">Age (in years):</label>
            <input type="number" id="age" name="age" value="<?php echo htmlspecialchars($age); ?>" min="0" step="0.1" required>

            <label for="weight">Weight (in Kg):</label>
            <input type="number" id="weight" name="weight" value="<?php echo htmlspecialchars($weight); ?>" step="0.01" min="0" required>

            <label>Spayed/Neutered:</label>
            <div class="spayed">
                <input type="radio" id="spayed_yes" name="spayed" value="yes" required>
                <label for="spayed_yes">Yes</label>

                <input type="radio" id="spayed_no" name="spayed" value="no">
                <label for="spayed_no">No</label>

                <input type="radio" id="spayed_unsure" name="spayed" value="unsure">
                <label for="spayed_unsure">Not applicable</label>
            </div>

            <label for="health_status">Health Status:</label>
            <textarea id="health_status" name="health_status"><?php echo htmlspecialchars($health); ?></textarea>

            <label for="description">Description:</label>
            <textarea id="description" name="description" required><?php echo htmlspecialchars($petDescription); ?></textarea>

            <h3>Selling Information</h3>
            <label for="price">Asking Price:</label>
            <input type="number" id="price" name="price" value="<?php echo htmlspecialchars($price); ?>" required min="0">

            <label for="reason">Reason for Selling:</label>
            <textarea id="reason" name="reason"><?php echo htmlspecialchars($reason); ?></textarea>

            <h3>Photos</h3>
            <label for="pet_photos">Upload Pet Photos:</label>
            <input type="file" id="pet_photos" name="pet_photos" multiple accept="image/*">
            <div class="button-container">
                <button type="button" class="cancel-button" onclick="window.location.href='dashboard.php'">Cancel</button>
                <button type="submit" name="submit">Submit</button>
            </div>
        </form>
    </div>
    <script>
        const form = document.getElementById('petForm');

        function validateForm() {
            const age = parseFloat(form.querySelector('#age').value);
            const weight = parseFloat(form.querySelector('#weight').value);
            const spayed = form.querySelector('input[name="spayed"]:checked');
            const price = parseFloat(form.querySelector('#price').value);
            const petName = form.querySelector('#pet_name').value.trim();
            const breed = form.querySelector('#breed').value.trim();
            const description = form.querySelector('#description').value.trim();


            if (isNaN(age) || age < 0) {
                alert('Please enter a valid age (positive number).');
                return false;
            }


            if (isNaN(weight) || weight < 0) {
                alert('Please enter a valid weight (positive number).');
                return false;
            }


            if (!spayed) {
                alert('Please select if the pet is spayed/neutered.');
                return false;
            }


            if (isNaN(price) || price < 0) {
                alert('Please enter a valid asking price (positive number).');
                return false;
            }


            if (petName === '') {
                alert('Please enter the pet\'s name.');
                return false;
            }


            if (breed === '') {
                alert('Please enter the pet\'s breed.');
                return false;
            }


            if (description === '') {
                alert('Please provide a description for the pet.');
                return false;
            }

            return true;
        }

        form.addEventListener('submit', function(event) {
            if (!validateForm()) {
                event.preventDefault();
            }
        });
    </script>
</body>

</html>