<?php

include('db.php');

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>petfinder.com</title>
    <script src="https://kit.fontawesome.com/524c5a650e.js" crossorigin="anonymous"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        h2 {
            background-image: linear-gradient(to right, red, blue);
            margin-bottom: 8px;
        }


        .about-section {
            padding: 18px;
            text-align: center;
            background-color: #3a3e47;
            color: rgba(255, 255, 255, 0.728);
        }

        .about-section ul {
            display: flex;
            flex-direction: row;
            justify-content: center;
            height: 40px;
        }

        .about-section ul li {
            list-style: none;
            font-size: 14px;
            margin-right: 20px;
        }

        .about-section ul li a {
            text-decoration: none;
            color: #fff;
        }

        .about-section ul li .fb:hover {
            color: rgb(0, 72, 255);
        }

        .about-section ul li .yt:hover {
            color: rgb(216, 26, 26);
        }

        .about-section ul li .ig:hover {
            color: rgb(166, 44, 65);
        }

        .about-section ul li .wa:hover {
            color: rgb(10, 174, 10);
        }

        .about-section ul li .tw:hover {
            color: rgb(0, 106, 255);
        }

        h1 {
            color: #ffe2e2;
        }

        nav .logo p {
            line-height: 60px;
            letter-spacing: 1px;
            font-weight: 800;
        }




        .column {
            display: flex;
            margin-bottom: 16px;
            justify-content: space-around;
            padding: 0 8px;
        }

        .card,
        .card2 {
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            margin: 4px;
            width: 440px;
            height: 350px;
        }

        .card img,
        .card2 img {
            margin-left: 33%;
            padding: 4px;
        }

        .card h2,
        .card2 h2 {
            text-align: center;
            background-clip: text;
            color: transparent
        }

        .container {
            padding: 0 16px;
        }

        .title {
            color: grey;
        }

        .button {
            margin-top: 4px;
            border: none;
            outline: 0;
            display: inline-block;
            padding: 8px;
            color: white;
            background-color: #000000e0;
            text-align: center;
            cursor: pointer;
            width: 100%;

        }

        .button:hover {
            background-color: #555;
        }

        /* Responsive layout for smaller screens */
        @media screen and (max-width: 650px) {
            .column {
                width: 100%;
                display: block;
            }
        }
    </style>
</head>

<body>
    <div class="about-section">
        <div class="logo">

            <img src="photo/logo.png" alt="" srcset="" style="width:200px;margin-bottom:20px" onclick=" window.location.href='Home.php';">
        </div>
        <h2>Welcome to Our Pet Adoption Service!</h2>
        <p>We provide a simple and convenient way for you to find the best pet adoption options available across the country. <br>Whether you're looking for a playful puppy, a cuddly kitten, or a loyal companion, we’re here to help you connect with the perfect pet for your home..</p>

        <h3>You can find us at:</h3>
        <ul>
            <li><a class="fb" href="www.facebook.com"><i class="fa-brands fa-facebook fa-xl"></i></a></li>
            <li><a class="yt" href="www.youtube.com"><i class="fa-brands fa-youtube fa-xl"></i></a></li>
            <li><a class="ig" href="www.instagram.com"><i class="fa-brands fa-instagram fa-xl"></i></a></li>
            <li><a class="wa" href="#"><i class="fa-brands fa-whatsapp fa-xl"></i></a></li>
            <li><a class="tw" href="www.twitter.com"><i class="fa-brands fa-twitter fa-xl"></i></a></li>
        </ul>
    </div>

    <h2 style="text-align:center; background-clip:text; color:transparent;">Our Team Members</h2>
    <div class="row">
        <div class="column">
            <div class="card">
                <img src="photo/manager-removebg-preview.jpg" alt="Jane" style="width:120px">
                <div class=" container">
                    <h2>Mr.Bishal Banjade</h2>
                    <p class="title">Team Manager</p>
                    <p>Expertise in web design and development</p>
                    <p>Under graduate in Bachelor of Computer Application</p>
                    <p>Student of LCC affilited to Tribhuwan University, Nepal</p>
                    <p>manbishalbanjade@gmail.com</p>
                    <p><button class="button">Contact</button></p>
                </div>
            </div>
            <div class="card2">
                <img src="photo/cat1.jpg" alt="Jane" style="width:120px">
                <div class="container">
                    <h2>Mr.pawan khanal</h2>
                    <p class="title">Team Member</p>
                    <p>Expertise in dubgging and code handling</p>
                    <p>Under graduate in Bachelor of Computer Application</p>
                    <p>Student of LCC affilited to Tribhuwan University, Nepal</p>
                    <p>pawankhanal@gmail.com</p>
                    <p><button class="button">Contact</button></p>
                </div>
            </div>
        </div>
    </div>
</body>

</html>