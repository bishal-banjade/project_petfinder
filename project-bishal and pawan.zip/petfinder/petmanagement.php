<?php

include 'db2.php';


$sql = "SELECT * FROM add_pets where upload=1";
$result = $conn->query($sql);
$newMessagesResult = $conn->query("SELECT COUNT(*) as total FROM add_pets WHERE upload = 0");
$newMessages = $newMessagesResult->fetch_assoc()['total'];


$successfulTransactionsResult = $conn->query("SELECT COUNT(*) as total FROM add_pets WHERE success = 1 AND payment = 0");
$successfulTransactions = $successfulTransactionsResult->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Pet Management</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            background-color: #fff;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #4CAF50;
            color: white;
            text-align: center;
        }

        img {
            max-width: 100px;

            height: auto;
            border-radius: 5px;
        }

        .delete-button {
            color: red;
            border: none;
            background: none;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <?php include 'adminnav.php' ?>
    <h2>Pet Management</h2>
    <table>
        <thead>
            <tr>
                <th>Owner ID</th>
                <th>Pet Name</th>
                <th>Pet Category</th>
                <th>Pet Breed</th>
                <th>Pet Price</th>
                <th>Reason to Sale</th>
                <th>Photo</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['owner_id']; ?></td>
                        <td><?php echo $row['pet_name']; ?></td>
                        <td><?php echo $row['pet_category']; ?></td>
                        <td><?php echo $row['pet_breed']; ?></td>
                        <td><?php echo $row['price']; ?></td>
                        <td><?php echo $row['Reasontosale']; ?></td>
                        <td><img src="<?php echo htmlspecialchars($row['pet_photos']); ?>" alt="Pet Photo" /></td>
                        <td>
                            <form action="delete_pet.php" method="POST" style="display:inline;">
                                <input type="hidden" name="pet_id" value="<?php echo $row['pet_id']; ?>">
                                <button type="submit" class="delete-button" onclick="return confirm('Are you sure you want to delete this pet?');">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="8">No pets found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    </div>

    <?php $conn->close(); ?>
</body>

</html>