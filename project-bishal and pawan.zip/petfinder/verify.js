function moveToNext(currentInput, nextInputId) {
  if (currentInput.value.length === 1 && /^[0-9]$/.test(currentInput.value)) {
    const nextInput = document.getElementById(nextInputId);
    nextInput.focus();
  } else if (currentInput.value.length === 0) {
    const previousInput = currentInput.previousElementSibling;
    if (previousInput) {
      previousInput.focus();
    }
  }
}

function verifyCode() {
  const digits = [
    document.getElementById("digit1").value,
    document.getElementById("digit2").value,
    document.getElementById("digit3").value,
    document.getElementById("digit4").value,
    document.getElementById("digit5").value,
    document.getElementById("digit6").value,
  ].join("");

  if (digits.length < 6) {
    alert("Please enter the complete verification code.");
    return;
  }
}
