<?php
include 'db.php';
require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$requestId = $_GET['request_id'];
$adopterEmail = $_GET['adopter_email'];
$ownerEmail = $_GET['owner_email'];

$stmt = $conn->prepare("UPDATE adoption_requests SET status = 'declined' WHERE request_id = ?");
$stmt->bind_param("i", $requestId);

if ($stmt->execute()) {

    $mail = new PHPMailer(true);
    try {

        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'finderpet275@gmail.com';
        $mail->Password = 'oydy pijk bjal hdci';
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;


        $mail->setFrom($ownerEmail, 'Adoption Agency');
        $mail->addAddress($adopterEmail);


        $mail->isHTML(true);
        $mail->Subject = 'Your Adoption Request Has Been Declined';
        $mail->Body = "<p>We're sorry, but your adoption request has been declined.</p>";

        $mail->send();
        echo 'Notification email has been sent to the adopter.';
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
} else {
    echo "Error updating request: " . $stmt->error;
}

$stmt->close();
$conn->close();
