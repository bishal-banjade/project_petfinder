<?php

include 'db.php';

session_start();
if (empty($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/Exception.php';
require 'phpmailer/PHPMailer.php';
require 'phpmailer/SMTP.php';

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

$address = $_SESSION['useraddress'];

if (isset($_GET['pet_id'])) {
    $pid = $_GET['pet_id'];
    $_SESSION['pid'] = $pid;

    // Update the pet status in the database to accept the deal
    $sql = "UPDATE add_pets SET success=1 WHERE pet_id='$pid'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        // Fetch pet details for email
        $sqlforemail = "SELECT * FROM add_pets WHERE pet_id='$pid'";
        $resultofemail = mysqli_query($conn, $sqlforemail);

        if ($resultofemail) {
            $rows = mysqli_fetch_assoc($resultofemail);
            $did = $rows['owner_id'];

            // Fetch adopter's details
            $mysql = "SELECT * FROM adopter WHERE adopter_id='$did'";
            $case = mysqli_query($conn, $mysql);
            $row = mysqli_fetch_assoc($case);

            if ($row) {
                $username = $row['adopter_name'];

                $mail = new PHPMailer(true);
                try {
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'finderpet275@gmail.com'; // Your Gmail address
                    $mail->Password = 'oydy pijk bjal hdci'; // Use an App Password if 2FA is enabled
                    $mail->SMTPSecure = 'ssl';
                    $mail->Port = 465;

                    $mail->setFrom('finderpet275@gmail.com', 'Pet Finder');
                    $mail->addAddress($row['adopter_email']);
                    $mail->isHTML(true);
                    $mail->Subject = "[petfinder.com User Adopter]";
                    $mail->Body = "<p>Dear " . htmlspecialchars($username) . ", congratulations! Your deal has been accepted by the owner.<br>You can proceed with the next steps. Check out the link to get redirected to the website.<br>Thank you<br><a href='http://localhost/petfinder/'>Visit Pet Finder</a></p>";

                    $mail->send();
                    header("Location:userpost.php");
                    exit();
                } catch (Exception $e) {
                    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
                }
            }
        }
    } else {
        echo "Error updating pet status: " . mysqli_error($conn);
    }
} else {
    echo "No pet ID provided.";
}
